'use client'

import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '../lib/supabase'
import { Search } from 'lucide-react'
import ConfirmDialog from '../components/ui/ConfirmDialog'
import Button from '../components/ui/Button'
import ApproverRow from '../components/org/ApproverRow'
import {
  DivisionRow,
  DepartmentRow,
  isDivisionHead,
  canManageDepartment,
  canManageDivision,
  canManageTeam,
  hasTopOrgAccess,
} from '../lib/orgPermissions'
import { pinHeadFirst } from '../lib/orgOrder'

interface TeamRow {
  id: string
  department_id: string
  name: string
  display_order: number
}
interface MemberRow {
  user_id: string
  name: string
}
interface TeamMemberRow extends MemberRow {
  team_id: string
  role: string
}
// 조직 관리 화면 안에서만 쓰는 순서변경 모드 상태.
// 'departments': 부문의 부서 목록 순서, 'teams': 부서의 팀 목록 순서, 'deptMembers': 부서의 구성원 순서(부서 직속 + 팀별)
type ReorderState =
  | { kind: 'divisions' }
  | { kind: 'departments'; divisionId: string }
  | { kind: 'teams'; departmentId: string }
  | { kind: 'deptMembers'; departmentId: string }
  | null
interface ProfileOption {
  id: string
  name: string
}
interface ApproverDelegateRow {
  id: string
  department_id: string
  user_id: string
  name: string
  can_vacation: boolean
  can_remote: boolean
  can_holiday: boolean
}
// 부문/팀 단위 결재권자 위임 (019_division_team_approvers) — department 버전과 같은 모양,
// 소속 컬럼명만 다르다.
interface DivisionApproverDelegateRow {
  id: string
  division_id: string
  user_id: string
  name: string
  can_vacation: boolean
  can_remote: boolean
  can_holiday: boolean
}
interface TeamApproverDelegateRow {
  id: string
  team_id: string
  user_id: string
  name: string
  can_vacation: boolean
  can_remote: boolean
  can_holiday: boolean
}
// 결재권자 위임 테이블은 부문/부서/팀 세 군데가 완전히 같은 모양이라 하나의 모달/제출
// 로직을 공유한다. scope가 어느 테이블(division_approvers/department_approvers/team_approvers)
// 에 쓸지를 가른다.
type ApproverScope = 'division' | 'department' | 'team'

type ModalState =
  | { kind: 'createDivision' }
  | { kind: 'createDepartment'; divisionId: string }
  | { kind: 'createTeam'; departmentId: string }
  | { kind: 'assignDivisionHead'; divisionId: string }
  | { kind: 'assignDepartmentHead'; departmentId: string }
  | { kind: 'assignTeamHead'; teamId: string; departmentId: string }
  | { kind: 'addApprover'; scope: ApproverScope; targetId: string }
  | null

type Selection =
  | { type: 'division'; id: string }
  | { type: 'department'; id: string }
  | { type: 'team'; id: string }
  | { type: 'unassigned' }
  | null

type TabKey = 'structure' | 'members' | 'permissions'

export default function OrgPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  // window.confirm/alert 대신 쓰는 확인창/오류 메시지 상태
  const [pendingConfirm, setPendingConfirm] = useState<{
    title: string
    description?: ReactNode
    confirmLabel?: string
    tone?: 'danger' | 'normal'
    onConfirm: () => void
  } | null>(null)
  const [isMaster, setIsMaster] = useState(false)
  const [isGeneralAdmin, setIsGeneralAdmin] = useState(false)
  const [checking, setChecking] = useState(true)
  const [message, setMessage] = useState('')

  const [divisions, setDivisions] = useState<DivisionRow[]>([])
  const [departments, setDepartments] = useState<DepartmentRow[]>([])
  const [teams, setTeams] = useState<TeamRow[]>([])
  const [teamMembers, setTeamMembers] = useState<TeamMemberRow[]>([])
  const [directMembers, setDirectMembers] = useState<(MemberRow & { department_id: string })[]>([])
  // 순서변경 모드 (req 6): null이면 평소대로, 값이 있으면 해당 목록만 드래그 가능하고 나머지는 비활성화
  const [reorder, setReorder] = useState<ReorderState>(null)
  const [approverDelegates, setApproverDelegates] = useState<ApproverDelegateRow[]>([])
  const [divisionApproverDelegates, setDivisionApproverDelegates] = useState<
    DivisionApproverDelegateRow[]
  >([])
  const [teamApproverDelegates, setTeamApproverDelegates] = useState<TeamApproverDelegateRow[]>(
    []
  )
  const [allProfiles, setAllProfiles] = useState<ProfileOption[]>([])

  // 사이드바 트리에서 펼쳐진 부문 목록 (기본은 모두 접힌 상태)
  const [expandedDiv, setExpandedDiv] = useState<Set<string>>(new Set())
  // 사이드바 트리에서 펼쳐진 부서 목록 (하위 팀을 보여줄지 여부, 기본은 모두 접힌 상태)
  const [expandedDept, setExpandedDept] = useState<Set<string>>(new Set())

  // 부서 상세의 "구조" 탭에서 펼쳐진 항목 ('direct' 또는 `team-${teamId}`)
  const [openStructureItem, setOpenStructureItem] = useState<string | null>(null)

  // 현재 메인 패널에 표시 중인 대상 (부문 또는 부서)
  const [selected, setSelected] = useState<Selection>(null)
  const [activeTab, setActiveTab] = useState<TabKey>('structure')
  const [search, setSearch] = useState('')
  const [menuOpenId, setMenuOpenId] = useState<string | null>(null)

  const [modal, setModal] = useState<ModalState>(null)
  const [modalInput, setModalInput] = useState('')
  const [modalUserId, setModalUserId] = useState('')
  const [modalChecks, setModalChecks] = useState({
    can_vacation: true,
    can_remote: true,
    can_holiday: true,
  })

  // 구성원 이동 인라인 폼
  const [movingKey, setMovingKey] = useState<string | null>(null)
  const [moveTargetDept, setMoveTargetDept] = useState<string>('')
  const [moveTargetTeam, setMoveTargetTeam] = useState<string>('')
  // 구성원 행의 ⋮ 메뉴(이동/내보내기 선택지) 펼침 상태 — 한 번에 하나만 펼쳐진다.
  const [openActionKey, setOpenActionKey] = useState<string | null>(null)

  // 미지정 인원 배정 인라인 폼
  const [assigningId, setAssigningId] = useState<string | null>(null)
  const [assignTargetDept, setAssignTargetDept] = useState<string>('')
  const [assignTargetTeam, setAssignTargetTeam] = useState<string>('')

  useEffect(() => {
    const init = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        router.push('/login')
        return
      }
      setUser(user)

      const { data: profileData } = await supabase
        .from('profiles')
        .select('is_master')
        .eq('id', user.id)
        .single()
      const master = !!profileData?.is_master
      setIsMaster(master)

      const { data: generalAdminRow } = await supabase
        .from('general_admins')
        .select('user_id')
        .eq('user_id', user.id)
        .maybeSingle()
      const generalAdmin = !!generalAdminRow
      setIsGeneralAdmin(generalAdmin)

      const { data: headDivisions } = await supabase
        .from('divisions')
        .select('id')
        .eq('head_user_id', user.id)
      const { data: headDepartments } = await supabase
        .from('departments')
        .select('id')
        .eq('head_user_id', user.id)
      // 팀장도 조직 관리 화면에 들어와서 페이지 조회 + 자기 팀 권한 관리를 할 수 있어야 한다.
      const { data: headTeams } = await supabase
        .from('team_members')
        .select('team_id')
        .eq('user_id', user.id)
        .eq('role', 'admin')

      const onlyTeamLead =
        !master &&
        !generalAdmin &&
        (headDivisions?.length ?? 0) === 0 &&
        (headDepartments?.length ?? 0) === 0 &&
        (headTeams?.length ?? 0) > 0

      if (
        !master &&
        !generalAdmin &&
        (headDivisions?.length ?? 0) === 0 &&
        (headDepartments?.length ?? 0) === 0 &&
        (headTeams?.length ?? 0) === 0
      ) {
        router.replace('/')
        return
      }

      await fetchAll()
      // 부문/부서 권한 없이 팀장 권한만 있는 사람은 자기 팀 화면을 기본으로 보여준다.
      if (onlyTeamLead && headTeams && headTeams.length > 0) {
        setSelected({ type: 'team', id: headTeams[0].team_id })
      }
      setChecking(false)
    }
    init()
  }, [])

  const fetchAll = async () => {
    const [divRes, depRes, teamRes, tmRes, dmRes, apRes, divApRes, teamApRes, profRes] =
      await Promise.all([
        supabase.from('divisions').select('id, name, head_user_id, display_order').order('display_order'),
        supabase
          .from('departments')
          .select('id, division_id, name, head_user_id')
          .order('division_id')
          .order('display_order'),
        supabase
          .from('teams')
          .select('id, department_id, name, display_order')
          .order('department_id')
          .order('display_order'),
        supabase
          .from('team_members')
          .select('team_id, user_id, role, profiles(name, email, is_master)')
          .order('team_id')
          .order('display_order'),
        supabase
          .from('department_memberships')
          .select('department_id, user_id, profiles(name, email, is_master)')
          .order('department_id')
          .order('display_order'),
        supabase
          .from('department_approvers')
          .select(
            'id, department_id, user_id, can_vacation, can_remote, can_holiday, profiles(name, email, is_master)'
          ),
        supabase
          .from('division_approvers')
          .select(
            'id, division_id, user_id, can_vacation, can_remote, can_holiday, profiles(name, email, is_master)'
          ),
        supabase
          .from('team_approvers')
          .select(
            'id, team_id, user_id, can_vacation, can_remote, can_holiday, profiles(name, email, is_master)'
          ),
        // 마스터(시스템 관리자) 계정은 조직 관리 화면에 노출하지 않는다 — 별도 권한 트랙이라 조직 구성원 풀에서 제외
        supabase
          .from('profiles')
          .select('id, name, email')
          .or('is_master.eq.false,is_master.is.null')
          .order('name'),
      ])

    const divs: DivisionRow[] = divRes.data || []
    setDivisions(divs)
    setDepartments(depRes.data || [])
    setTeams((teamRes.data || []).filter((t: any) => t.department_id))
    setTeamMembers(
      (tmRes.data || [])
        .filter((m: any) => !m.profiles?.is_master)
        .map((m: any) => ({
          team_id: m.team_id,
          user_id: m.user_id,
          role: m.role,
          name: m.profiles?.name || m.profiles?.email?.split('@')[0] || '이름없음',
        }))
    )
    setDirectMembers(
      (dmRes.data || [])
        .filter((m: any) => !m.profiles?.is_master)
        .map((m: any) => ({
          department_id: m.department_id,
          user_id: m.user_id,
          name: m.profiles?.name || m.profiles?.email?.split('@')[0] || '이름없음',
        }))
    )
    setApproverDelegates(
      (apRes.data || [])
        .filter((a: any) => !a.profiles?.is_master)
        .map((a: any) => ({
          id: a.id,
          department_id: a.department_id,
          user_id: a.user_id,
          name: a.profiles?.name || a.profiles?.email?.split('@')[0] || '이름없음',
          can_vacation: a.can_vacation,
          can_remote: a.can_remote,
          can_holiday: a.can_holiday,
        }))
    )
    setDivisionApproverDelegates(
      (divApRes.data || [])
        .filter((a: any) => !a.profiles?.is_master)
        .map((a: any) => ({
          id: a.id,
          division_id: a.division_id,
          user_id: a.user_id,
          name: a.profiles?.name || a.profiles?.email?.split('@')[0] || '이름없음',
          can_vacation: a.can_vacation,
          can_remote: a.can_remote,
          can_holiday: a.can_holiday,
        }))
    )
    setTeamApproverDelegates(
      (teamApRes.data || [])
        .filter((a: any) => !a.profiles?.is_master)
        .map((a: any) => ({
          id: a.id,
          team_id: a.team_id,
          user_id: a.user_id,
          name: a.profiles?.name || a.profiles?.email?.split('@')[0] || '이름없음',
          can_vacation: a.can_vacation,
          can_remote: a.can_remote,
          can_holiday: a.can_holiday,
        }))
    )
    setAllProfiles(
      (profRes.data || []).map((p: any) => ({
        id: p.id,
        name: p.name || p.email?.split('@')[0] || '이름없음',
      }))
    )

    // 최초 로딩 시 첫 부문을 기본 선택 (이미 선택된 항목이 있으면 유지)
    setSelected((prev) => {
      if (prev) return prev
      return divs.length > 0 ? { type: 'division', id: divs[0].id } : null
    })
  }

  const profileName = (id: string | null) =>
    id ? allProfiles.find((p) => p.id === id)?.name || '알 수 없음' : null

  const teamsInDept = (departmentId: string) =>
    teams.filter((t) => t.department_id === departmentId)
  // 팀 구성원 목록: 팀장(admin)이 항상 최상단에 오도록 정렬한다.
  // 대시보드/내소속과 동일한 규칙(lib/orgOrder의 pinHeadFirst)을 그대로 사용한다.
  const membersOfTeam = (teamId: string) =>
    pinHeadFirst(
      teamMembers.filter((m) => m.team_id === teamId).map((m) => ({ ...m, isHead: m.role === 'admin' }))
    )
  const directOfDept = (departmentId: string) =>
    directMembers.filter((m) => m.department_id === departmentId)
  // 부서 직속 구성원 "표시용" 목록: 저장된 순서(display_order)를 따르되 부서장은 항상 최상단.
  // 구성원 탭/팀 구성원 목록과 같은 규칙(pinHeadFirst)이다. 부서장이 직속 소속 레코드에 없어도
  // (자리만 있는 경우) 목록과 인원수에 포함해 구성원 탭과 어긋나지 않게 한다.
  const orderedDirectsOfDept = (department: DepartmentRow) => {
    const list = directOfDept(department.id)
    const headId = department.head_user_id
    const withHead =
      headId && !list.some((m) => m.user_id === headId)
        ? [
            {
              user_id: headId,
              name: profileName(headId) || '알 수 없음',
              department_id: department.id,
            },
            ...list,
          ]
        : list
    return pinHeadFirst(withHead.map((m) => ({ ...m, isHead: !!headId && m.user_id === headId })))
  }
  const approversOfDept = (departmentId: string) =>
    approverDelegates.filter((a) => a.department_id === departmentId)
  const approversOfDivision = (divisionId: string) =>
    divisionApproverDelegates.filter((a) => a.division_id === divisionId)
  const approversOfTeam = (teamId: string) =>
    teamApproverDelegates.filter((a) => a.team_id === teamId)
  const departmentsOfDivision = (divisionId: string) =>
    departments.filter((d) => d.division_id === divisionId)

  // 부서/부문 인원수는 "고유 인원" 기준으로 센다.
  // - 팀장/부서장/부문장을 겸임해도 한 명은 한 번만 카운트한다 (Set으로 중복 제거)
  // - 부문장은 하위 부서/팀에 소속되어 있지 않아도 그 부문의 인원수에 포함된다
  const memberIdsOfDept = (departmentId: string): Set<string> => {
    const ids = new Set<string>()
    directOfDept(departmentId).forEach((m) => ids.add(m.user_id))
    teamsInDept(departmentId).forEach((t) => membersOfTeam(t.id).forEach((m) => ids.add(m.user_id)))
    const dept = departments.find((d) => d.id === departmentId)
    if (dept?.head_user_id) ids.add(dept.head_user_id)
    return ids
  }
  const headcountOfDept = (departmentId: string) => memberIdsOfDept(departmentId).size

  const memberIdsOfDivision = (divisionId: string): Set<string> => {
    const ids = new Set<string>()
    departmentsOfDivision(divisionId).forEach((d) =>
      memberIdsOfDept(d.id).forEach((id) => ids.add(id))
    )
    const division = divisions.find((d) => d.id === divisionId)
    if (division?.head_user_id) ids.add(division.head_user_id)
    return ids
  }
  const headcountOfDivision = (divisionId: string) => memberIdsOfDivision(divisionId).size

  // ---------- 조직장 임명 후보 ----------
  // 부문장을 임명하는 총괄 관리자/마스터는 이미 조직 전체에 대한 권한을 가지므로
  // 후보 제한이 필요 없다. 하지만 그 아래(부문장이 부서장을, 부서장이 팀장을 임명)로
  // 내려가면 "자신의 권한이 미치는 인원(해당 부문/부서 소속) + 미지정 인원"만 후보로
  // 노출해서, 다른 부문·부서 소속 인원을 함부로 데려오지 못하게 한다.
  const candidatesForDivision = (divisionId: string): ProfileOption[] => {
    const ids = memberIdsOfDivision(divisionId)
    return allProfiles.filter((p) => ids.has(p.id) || unassignedProfiles.some((u) => u.id === p.id))
  }
  const candidatesForDepartment = (departmentId: string): ProfileOption[] => {
    const ids = memberIdsOfDept(departmentId)
    return allProfiles.filter((p) => ids.has(p.id) || unassignedProfiles.some((u) => u.id === p.id))
  }

  // ---------- 미지정 인원 ----------
  // 어느 팀에도, 어느 부서에도(직접 소속으로도) 속하지 않은 사람 = 미지정 인원.
  // 단, 부문장/부서장은 조직의 장으로 임명된 것 자체로 소속이 인정되므로
  // (부문장은 애초에 부서/팀에 소속될 필요가 없고, 부서장은 임명 시 자동으로
  // 해당 부서에 소속 처리된다) 미지정 인원 목록에서 제외한다.
  const unassignedProfiles = allProfiles.filter(
    (p) =>
      !teamMembers.some((m) => m.user_id === p.id) &&
      !directMembers.some((m) => m.user_id === p.id) &&
      !divisions.some((d) => d.head_user_id === p.id) &&
      !departments.some((d) => d.head_user_id === p.id)
  )

  // 이 사람이 배정 권한을 행사할 수 있는 부서 목록.
  // - 마스터: 전체 부서
  // - 부문장: 자신의 부문에 속한 모든 부서
  // - 부서장: 자신의 부서만
  // (canManageDepartment가 위 두 조건을 이미 포함해서 판별해준다)
  // 조직 관리 권한 트랙의 최상위 접근 여부 (시스템 관리자 또는 총괄 관리자)
  const hasTopAccess = hasTopOrgAccess(isMaster, isGeneralAdmin)

  const assignableDepartments = (): DepartmentRow[] =>
    hasTopAccess
      ? departments
      : departments.filter((d) =>
          canManageDepartment(user.id, d.id, departments, divisions, hasTopAccess)
        )

  // 이 사람이 팀장인 팀 목록. 부서/부문 권한은 없이 팀장 권한만 있는 사람이
  // "미지정 인원"을 자기 팀으로 직접 배속할 때 쓴다 (부서 선택 없이 팀만 고른다).
  const myLeadTeams = (): TeamRow[] =>
    hasTopAccess
      ? []
      : teams.filter((t) =>
          teamMembers.some(
            (m) => m.team_id === t.id && m.user_id === user.id && m.role === 'admin'
          )
        )

  const toggleExpand = (id: string) => {
    setExpandedDiv((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  // 사이드바에서 부문을 클릭했을 때: 선택 + 펼침/접힘 토글.
  // 오른쪽 메인 패널에 이미 이 부문이 표시되고 있는 상태에서 다시 누르면 접히고,
  // 그 외의 경우(다른 항목이 표시 중이거나 접혀 있는 경우)에는 이 부문을 선택하고 펼친다.
  const handleDivisionRowClick = (id: string) => {
    const isShowingThis = selected?.type === 'division' && selected.id === id
    if (isShowingThis && expandedDiv.has(id)) {
      setExpandedDiv((prev) => {
        const next = new Set(prev)
        next.delete(id)
        return next
      })
    } else {
      selectDivision(id)
    }
  }

  // 사이드바에서 부서를 클릭했을 때: 선택 + 하위 팀 펼침/접힘 토글.
  // 오른쪽 메인 패널에 이미 이 부서가 표시되고 있는 상태에서 다시 누르면 접히고,
  // 그 외의 경우에는 이 부서를 선택하고 하위 팀을 펼친다.
  const handleDepartmentRowClick = (id: string) => {
    const isShowingThis = selected?.type === 'department' && selected.id === id
    if (isShowingThis && expandedDept.has(id)) {
      setExpandedDept((prev) => {
        const next = new Set(prev)
        next.delete(id)
        return next
      })
    } else {
      selectDepartment(id)
    }
  }

  // ---------- 선택 ----------
  const selectDivision = (id: string) => {
    setSelected({ type: 'division', id })
    setActiveTab('structure')
    setMenuOpenId(null)
    setOpenStructureItem(null)
    setExpandedDiv((prev) => new Set(prev).add(id))
  }
  const selectDepartment = (id: string) => {
    setSelected({ type: 'department', id })
    setActiveTab('structure')
    setMenuOpenId(null)
    setOpenStructureItem(null)
    const dep = departments.find((d) => d.id === id)
    if (dep) setExpandedDiv((prev) => new Set(prev).add(dep.division_id))
    setExpandedDept((prev) => new Set(prev).add(id))
  }
  const selectTeam = (id: string) => {
    setSelected({ type: 'team', id })
    setActiveTab('members')
    setMenuOpenId(null)
    setOpenStructureItem(null)
    const team = teams.find((t) => t.id === id)
    const dept = team ? departments.find((d) => d.id === team.department_id) : null
    if (dept) {
      setExpandedDiv((prev) => new Set(prev).add(dept.division_id))
      setExpandedDept((prev) => new Set(prev).add(dept.id))
    }
  }

  // ---------- 검색 ----------
  const searchTerm = search.trim().toLowerCase()
  const matchesTerm = (name: string) => !searchTerm || name.toLowerCase().includes(searchTerm)
  const departmentMatchesSearch = (dept: DepartmentRow) =>
    matchesTerm(dept.name) || teamsInDept(dept.id).some((t) => matchesTerm(t.name))
  const divisionMatchesSearch = (division: DivisionRow) =>
    matchesTerm(division.name) || departmentsOfDivision(division.id).some(departmentMatchesSearch)
  const visibleDivisions = divisions.filter(divisionMatchesSearch)

  // 모바일은 트리 사이드바 대신 부문 select + 드릴다운 방식이라, 검색어가 있을 때는
  // 부문/부서/팀을 한 번에 훑어 탭 한 번으로 바로 이동할 수 있는 평탄화된 결과 목록을 보여준다.
  type MobileSearchResult =
    | { kind: 'division'; division: DivisionRow }
    | { kind: 'department'; division: DivisionRow; department: DepartmentRow }
    | { kind: 'team'; division: DivisionRow; department: DepartmentRow; team: TeamRow }
  const mobileSearchResults: MobileSearchResult[] = []
  if (searchTerm) {
    divisions.forEach((division) => {
      if (matchesTerm(division.name)) mobileSearchResults.push({ kind: 'division', division })
      departmentsOfDivision(division.id).forEach((department) => {
        if (matchesTerm(department.name))
          mobileSearchResults.push({ kind: 'department', division, department })
        teamsInDept(department.id).forEach((team) => {
          if (matchesTerm(team.name))
            mobileSearchResults.push({ kind: 'team', division, department, team })
        })
      })
    })
  }

  // ---------- 모달 열기/닫기 ----------
  const openModal = (m: ModalState) => {
    setModal(m)
    setModalInput('')
    setModalUserId('')
    setModalChecks({ can_vacation: true, can_remote: true, can_holiday: true })
    setMessage('')
  }
  const closeModal = () => setModal(null)

  const submitModal = async () => {
    if (!modal) return

    if (modal.kind === 'createDivision') {
      if (!modalInput.trim()) return
      const { error } = await supabase
        .from('divisions')
        .insert({ name: modalInput.trim(), display_order: divisions.length })
      if (error) {
        setMessage('부문 생성 실패: ' + error.message)
        return
      }
    }

    if (modal.kind === 'createDepartment') {
      if (!modalInput.trim()) return
      const { error } = await supabase
        .from('departments')
        .insert({ division_id: modal.divisionId, name: modalInput.trim() })
      if (error) {
        setMessage('부서 생성 실패: ' + error.message)
        return
      }
    }

    if (modal.kind === 'createTeam') {
      if (!modalInput.trim()) return
      // 팀 생성자를 자동으로 팀장으로 지정하지 않는다 — 생성과 팀장 지정은 별개 작업
      const { error } = await supabase
        .from('teams')
        .insert({ name: modalInput.trim(), department_id: modal.departmentId, created_by: user.id })
      if (error) {
        setMessage('팀 생성 실패: ' + error.message)
        return
      }
    }

    if (modal.kind === 'assignDivisionHead') {
      const { error } = await supabase
        .from('divisions')
        .update({ head_user_id: modalUserId || null, updated_at: new Date().toISOString() })
        .eq('id', modal.divisionId)
      if (error) {
        setMessage('부문장 지정 실패: ' + error.message)
        return
      }
    }

    if (modal.kind === 'assignDepartmentHead') {
      // 교체되기 전의 부서장을 먼저 기억해둔다 (아래에서 그 사람의 겸임 잔여 소속을 정리하기 위함).
      const previousHeadId =
        departments.find((d) => d.id === modal.departmentId)?.head_user_id || null

      const { error } = await supabase
        .from('departments')
        .update({ head_user_id: modalUserId || null, updated_at: new Date().toISOString() })
        .eq('id', modal.departmentId)
      if (error) {
        setMessage('부서장 지정 실패: ' + error.message)
        return
      }

      // 부서장으로 임명되면 자동으로 그 부서 소속이 되어야 한다.
      // 이미 그 부서(팀 소속 포함)에 속해 있다면 중복으로 추가하지 않는다.
      if (modalUserId) {
        const alreadyBelongsToDept =
          directMembers.some(
            (m) => m.department_id === modal.departmentId && m.user_id === modalUserId
          ) ||
          teamsInDept(modal.departmentId).some((t) =>
            membersOfTeam(t.id).some((m) => m.user_id === modalUserId)
          )
        if (!alreadyBelongsToDept) {
          await supabase
            .from('department_memberships')
            .insert({ department_id: modal.departmentId, user_id: modalUserId })
        }
      }

      // 방금 자리에서 물러난 이전 부서장이 이 부서가 속한 부문의 부문장을 겸임하고 있었다면,
      // 부서장 임명 시 자동으로 붙었던 "부서 직속" 잔여 소속을 함께 정리한다.
      // (부문장은 부서에 소속될 필요 없이도 산하 모든 부서에 접근 가능하므로, 부서장 자리에서
      //  내려온 뒤에는 부문장으로만 남아야 하고 부서 직속으로 남아있으면 안 된다.)
      if (previousHeadId && previousHeadId !== modalUserId) {
        const dept = departments.find((d) => d.id === modal.departmentId)
        const parentDivision = dept ? divisions.find((dv) => dv.id === dept.division_id) : null
        if (parentDivision?.head_user_id === previousHeadId) {
          await supabase
            .from('department_memberships')
            .delete()
            .eq('department_id', modal.departmentId)
            .eq('user_id', previousHeadId)
        }
      }
    }

    if (modal.kind === 'assignTeamHead') {
      if (modalUserId) {
        await performAssignTeamLead(modal.teamId, modal.departmentId, modalUserId)
      } else {
        const currentLeads = teamMembers.filter(
          (m) => m.team_id === modal.teamId && m.role === 'admin'
        )
        for (const lead of currentLeads) {
          await performDemoteTeamLead(modal.teamId, lead.user_id)
        }
      }
    }

    if (modal.kind === 'addApprover') {
      if (!modalUserId) {
        setMessage('결재권자로 위임할 사람을 선택해주세요.')
        return
      }
      const table = approverTableOf(modal.scope)
      const idField = approverIdFieldOf(modal.scope)
      const { error } = await supabase.from(table).upsert(
        {
          [idField]: modal.targetId,
          user_id: modalUserId,
          ...modalChecks,
        },
        { onConflict: `${idField},user_id` }
      )
      if (error) {
        setMessage('결재권자 위임 실패: ' + error.message)
        return
      }
    }

    closeModal()
    fetchAll()
  }

  // 결재권자 위임 테이블은 부문/부서/팀 세 군데가 완전히 같은 모양이라 scope로 테이블/컬럼명만 가른다.
  const approverTableOf = (scope: ApproverScope) =>
    scope === 'division'
      ? 'division_approvers'
      : scope === 'team'
        ? 'team_approvers'
        : 'department_approvers'
  const approverIdFieldOf = (scope: ApproverScope) => `${scope}_id`

  const handleRemoveApprover = async (scope: ApproverScope, id: string) => {
    await supabase.from(approverTableOf(scope)).delete().eq('id', id)
    fetchAll()
  }

  const confirmRemoveApprover = (scope: ApproverScope, id: string) => {
    setPendingConfirm({
      title: '이 사람의 결재권자 위임을 해제할까요?',
      confirmLabel: '해제',
      tone: 'danger',
      onConfirm: () => {
        setPendingConfirm(null)
        handleRemoveApprover(scope, id)
      },
    })
  }

  // ---------- 팀장 지정/해제 ----------
  // 팀장은 한 명만 가능 — 새로 지정하면 기존 팀장은 자동으로 해제된다.
  const performAssignTeamLead = async (teamId: string, departmentId: string, userId: string) => {
    const currentLeads = teamMembers.filter(
      (m) => m.team_id === teamId && m.role === 'admin' && m.user_id !== userId
    )
    for (const lead of currentLeads) {
      await supabase
        .from('team_members')
        .update({ role: 'member' })
        .eq('team_id', teamId)
        .eq('user_id', lead.user_id)
    }

    const oldTeamMembership = teamMembers.find(
      (m) =>
        m.user_id === userId &&
        m.team_id !== teamId &&
        teams.find((t) => t.id === m.team_id)?.department_id === departmentId
    )
    if (oldTeamMembership) {
      await supabase
        .from('team_members')
        .delete()
        .eq('team_id', oldTeamMembership.team_id)
        .eq('user_id', userId)
    }
    await supabase
      .from('department_memberships')
      .delete()
      .eq('department_id', departmentId)
      .eq('user_id', userId)

    const existing = teamMembers.find((m) => m.team_id === teamId && m.user_id === userId)
    if (existing) {
      await supabase
        .from('team_members')
        .update({ role: 'admin' })
        .eq('team_id', teamId)
        .eq('user_id', userId)
    } else {
      await supabase
        .from('team_members')
        .insert({ team_id: teamId, user_id: userId, role: 'admin' })
    }
  }

  const performDemoteTeamLead = async (teamId: string, userId: string) => {
    await supabase
      .from('team_members')
      .update({ role: 'member' })
      .eq('team_id', teamId)
      .eq('user_id', userId)
  }

  // 이 팀의 현재 팀장(1명) 조회
  const teamLeadOf = (teamId: string) =>
    teamMembers.find((m) => m.team_id === teamId && m.role === 'admin') || null

  // ---------- 구성원 이동 ----------
  const departmentsForActor = (
    division: DivisionRow,
    departmentIdHint: string
  ): DepartmentRow[] => {
    if (hasTopAccess) return departments
    if (isDivisionHead(user.id, division, hasTopAccess))
      return departments.filter((d) => d.division_id === division.id)
    return departments.filter((d) => d.id === departmentIdHint)
  }

  const openMove = (key: string, currentDepartmentId: string, currentTeamId: string | null) => {
    setOpenActionKey(null)
    setMovingKey(key)
    setMoveTargetDept(currentDepartmentId)
    setMoveTargetTeam(currentTeamId || '')
  }
  const closeMove = () => {
    setMovingKey(null)
    setMoveTargetDept('')
    setMoveTargetTeam('')
  }

  // ---------- 미지정 인원 배정 ----------
  const openAssign = (userId: string) => {
    const myDepts = assignableDepartments()
    setAssigningId(userId)
    if (myDepts.length > 0) {
      setAssignTargetDept(myDepts[0]?.id || '')
      setAssignTargetTeam('')
    } else {
      // 부서/부문 권한은 없고 팀장 권한만 있는 경우: 부서 선택 없이 자기 팀으로 바로 배정
      setAssignTargetDept('')
      setAssignTargetTeam(myLeadTeams()[0]?.id || '')
    }
  }
  const closeAssign = () => {
    setAssigningId(null)
    setAssignTargetDept('')
    setAssignTargetTeam('')
  }

  const handleConfirmAssign = async (userId: string) => {
    if (!assignTargetDept && !assignTargetTeam) return
    if (assignTargetTeam) {
      const { error } = await supabase
        .from('team_members')
        .insert({ team_id: assignTargetTeam, user_id: userId, role: 'member' })
      if (error) {
        setMessage('배정 실패: ' + error.message)
        return
      }
    } else {
      const { error } = await supabase
        .from('department_memberships')
        .insert({ department_id: assignTargetDept, user_id: userId })
      if (error) {
        setMessage('배정 실패: ' + error.message)
        return
      }
    }
    closeAssign()
    fetchAll()
  }

  // ---------- 소속 해제 (내보내기) ----------
  // 내보내기는 "그 조작이 일어난 범위"만 해제한다. 겸임 중인 상위/별개 직위(예: 부문장)는
  // 이 부서·팀과 무관하게 유지되는 독립적인 자리이므로 함께 해제하지 않는다.
  // 예) 부문장을 겸임 중인 부서장을 부서에서 내보내면 그 부서 소속·부서장 자리만 사라지고
  //     부문장 지위는 그대로 남는다. (부문장 자리를 비우려면 "부문장 변경"에서 공석으로 지정)

  // 팀에서 내보내기: 그 팀 소속만 해제한다. 부서 직속/다른 팀/부서장·부문장 등은 그대로 유지된다.
  const handleUnassignFromTeam = async (teamId: string, userId: string) => {
    await supabase.from('team_members').delete().eq('team_id', teamId).eq('user_id', userId)
    fetchAll()
  }

  const confirmUnassignFromTeam = (teamId: string, userId: string) => {
    setPendingConfirm({
      title: '이 사람을 이 팀에서 내보낼까요?',
      confirmLabel: '내보내기',
      tone: 'danger',
      onConfirm: () => {
        setPendingConfirm(null)
        handleUnassignFromTeam(teamId, userId)
      },
    })
  }

  // 부서에서 내보내기: 그 부서 직속 소속과 그 부서 산하 팀 소속을 모두 해제한다.
  // 내보내는 대상이 이 부서의 부서장이었다면 부서장 자리도 함께 비운다(부서에 속하지 않으면서
  // 부서장일 수는 없으므로). 다만 이 사람이 겸임 중인 부문장 등 다른 조직의 직위는 건드리지 않는다.
  const handleUnassignFromDept = async (departmentId: string, userId: string) => {
    if (!departmentId) return
    const deptTeamIds = teamsInDept(departmentId).map((t) => t.id)
    await Promise.all([
      supabase
        .from('department_memberships')
        .delete()
        .eq('department_id', departmentId)
        .eq('user_id', userId),
      ...(deptTeamIds.length > 0
        ? [supabase.from('team_members').delete().eq('user_id', userId).in('team_id', deptTeamIds)]
        : []),
      supabase
        .from('departments')
        .update({ head_user_id: null, updated_at: new Date().toISOString() })
        .eq('id', departmentId)
        .eq('head_user_id', userId),
    ])
    fetchAll()
  }

  const confirmUnassignFromDept = (departmentId: string, userId: string) => {
    if (!departmentId) return
    setPendingConfirm({
      title: '이 사람을 이 부서에서 내보낼까요?',
      confirmLabel: '내보내기',
      tone: 'danger',
      onConfirm: () => {
        setPendingConfirm(null)
        handleUnassignFromDept(departmentId, userId)
      },
    })
  }

  const handleConfirmMove = async (
    userId: string,
    fromTeamId: string | null,
    fromDepartmentId: string
  ) => {
    if (!moveTargetDept) return
    if (fromTeamId) {
      await supabase.from('team_members').delete().eq('team_id', fromTeamId).eq('user_id', userId)
    } else {
      await supabase
        .from('department_memberships')
        .delete()
        .eq('department_id', fromDepartmentId)
        .eq('user_id', userId)
    }
    if (moveTargetTeam) {
      await supabase
        .from('team_members')
        .insert({ team_id: moveTargetTeam, user_id: userId, role: 'member' })
    } else {
      await supabase
        .from('department_memberships')
        .insert({ department_id: moveTargetDept, user_id: userId })
    }
    closeMove()
    fetchAll()
  }

  // ---------- 부문/부서/팀 삭제 ----------
  // 하위 조직이나 인원이 남아있어도 삭제할 수 있다. 팀/부서/부문을 지우면
  // 그 아래 팀도 함께 지워지고(DB에서 CASCADE), 소속돼 있던 인원은 그 소속에서만
  // 끊어질 뿐 계정 자체는 남아 "미지정 인원"으로 이동한다 — 삭제 전 몇 명이
  // 영향을 받는지 확인창에서 미리 안내한다.
  const handleDeleteDivision = async (division: DivisionRow) => {
    const { error } = await supabase.from('divisions').delete().eq('id', division.id)
    if (error) {
      setMessage('부문 삭제 실패: ' + error.message)
      return
    }
    setSelected((prev) => (prev?.type === 'division' && prev.id === division.id ? null : prev))
    fetchAll()
  }

  const confirmDeleteDivision = (division: DivisionRow) => {
    const deptCount = departmentsOfDivision(division.id).length
    const memberCount = headcountOfDivision(division.id)
    const warning =
      deptCount > 0 || memberCount > 0 ? (
        <>
          이 부문에는 부서 {deptCount}개, 인원 {memberCount}명이 있어요. 삭제하면 하위 부서와
          팀이 모두 함께 삭제되고, 소속돼 있던 인원은 <strong>미지정 인원</strong> 상태가 돼요.
        </>
      ) : undefined
    setPendingConfirm({
      title: `'${division.name}' 부문을 삭제할까요?`,
      description: warning,
      confirmLabel: '삭제',
      tone: 'danger',
      onConfirm: () => {
        setPendingConfirm(null)
        handleDeleteDivision(division)
      },
    })
  }

  const handleDeleteTeam = async (team: TeamRow) => {
    const { error } = await supabase.from('teams').delete().eq('id', team.id)
    if (error) {
      setMessage('팀 삭제 실패: ' + error.message)
      return
    }
    setOpenStructureItem((prev) => (prev === `team-${team.id}` ? null : prev))
    setSelected((prev) =>
      prev?.type === 'team' && prev.id === team.id
        ? { type: 'department', id: team.department_id }
        : prev
    )
    fetchAll()
  }

  const confirmDeleteTeam = (team: TeamRow) => {
    const memberCount = membersOfTeam(team.id).length
    const warning =
      memberCount > 0 ? (
        <>
          이 팀에는 구성원 {memberCount}명이 있어요. 삭제하면 인원은{' '}
          <strong>미지정 인원</strong> 상태가 돼요.
        </>
      ) : undefined
    setPendingConfirm({
      title: `'${team.name}' 팀을 삭제할까요?`,
      description: warning,
      confirmLabel: '삭제',
      tone: 'danger',
      onConfirm: () => {
        setPendingConfirm(null)
        handleDeleteTeam(team)
      },
    })
  }

  const handleDeleteDepartment = async (department: DepartmentRow) => {
    const { error } = await supabase.from('departments').delete().eq('id', department.id)
    if (error) {
      setMessage('부서 삭제 실패: ' + error.message)
      return
    }
    setSelected((prev) =>
      prev?.type === 'department' && prev.id === department.id
        ? { type: 'division', id: department.division_id }
        : prev
    )
    fetchAll()
  }

  const confirmDeleteDepartment = (department: DepartmentRow) => {
    const teamCount = teamsInDept(department.id).length
    const memberCount = headcountOfDept(department.id)
    const warning =
      teamCount > 0 || memberCount > 0 ? (
        <>
          이 부서에는 팀 {teamCount}개, 인원 {memberCount}명이 있어요. 삭제하면 하위 팀도 함께
          삭제되고, 소속돼 있던 인원은 <strong>미지정 인원</strong> 상태가 돼요.
        </>
      ) : undefined
    setPendingConfirm({
      title: `'${department.name}' 부서를 삭제할까요?`,
      description: warning,
      confirmLabel: '삭제',
      tone: 'danger',
      onConfirm: () => {
        setPendingConfirm(null)
        handleDeleteDepartment(department)
      },
    })
  }

  // ── 순서 변경 (req 4, 5, 6, 8) ─────────────────────────────────────────
  // 특정 그룹(같은 부문 소속 부서들, 같은 부서 소속 팀들, 같은 부서 직속 인원, 같은 팀 인원)만
  // 새 순서로 갈아끼우고 나머지 항목은 원래 자리를 유지한다.
  function replaceGroup<T>(all: T[], inGroup: (item: T) => boolean, newGroupOrder: T[]): T[] {
    const result: T[] = []
    let inserted = false
    for (const item of all) {
      if (inGroup(item)) {
        if (!inserted) {
          result.push(...newGroupOrder)
          inserted = true
        }
      } else {
        result.push(item)
      }
    }
    if (!inserted) result.push(...newGroupOrder)
    return result
  }

  const startReorderDivisions = () => {
    setMenuOpenId(null)
    setReorder({ kind: 'divisions' })
  }
  const startReorderDepartments = (divisionId: string) => {
    setSelected({ type: 'division', id: divisionId })
    setActiveTab('structure')
    setMenuOpenId(null)
    setReorder({ kind: 'departments', divisionId })
  }
  const startReorderTeams = (departmentId: string) => {
    setSelected({ type: 'department', id: departmentId })
    setActiveTab('structure')
    setMenuOpenId(null)
    setReorder({ kind: 'teams', departmentId })
  }
  const startReorderDeptMembers = (departmentId: string) => {
    setSelected({ type: 'department', id: departmentId })
    setActiveTab('members')
    setMenuOpenId(null)
    setReorder({ kind: 'deptMembers', departmentId })
  }
  const cancelReorder = () => {
    setReorder(null)
    fetchAll()
  }
  const finishReorder = async () => {
    if (!reorder) return
    try {
      if (reorder.kind === 'divisions') {
        await Promise.all(
          divisions.map((d, idx) =>
            supabase.from('divisions').update({ display_order: idx }).eq('id', d.id)
          )
        )
      } else if (reorder.kind === 'departments') {
        const group = departments.filter((d) => d.division_id === reorder.divisionId)
        await Promise.all(
          group.map((d, idx) =>
            supabase.from('departments').update({ display_order: idx }).eq('id', d.id)
          )
        )
      } else if (reorder.kind === 'teams') {
        const group = teams.filter((t) => t.department_id === reorder.departmentId)
        await Promise.all(
          group.map((t, idx) =>
            supabase.from('teams').update({ display_order: idx }).eq('id', t.id)
          )
        )
      } else if (reorder.kind === 'deptMembers') {
        const directGroup = directMembers.filter((m) => m.department_id === reorder.departmentId)
        const tasks = directGroup.map((m, idx) =>
          supabase
            .from('department_memberships')
            .update({ display_order: idx })
            .eq('department_id', reorder.departmentId)
            .eq('user_id', m.user_id)
        )
        const teamIds = teams
          .filter((t) => t.department_id === reorder.departmentId)
          .map((t) => t.id)
        teamIds.forEach((teamId) => {
          const group = teamMembers.filter((m) => m.team_id === teamId)
          group.forEach((m, idx) => {
            tasks.push(
              supabase
                .from('team_members')
                .update({ display_order: idx })
                .eq('team_id', teamId)
                .eq('user_id', m.user_id)
            )
          })
        })
        await Promise.all(tasks)
      }
    } finally {
      setReorder(null)
      fetchAll()
    }
  }
  // 순서변경 모드일 때 "지금 활성화된 그룹"이 아닌 나머지 UI에 적용할 비활성/저채도 스타일
  const dimClass = (active: boolean) =>
    active ? '' : 'opacity-40 pointer-events-none select-none transition-opacity'

  if (checking) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-zinc-900 p-2 sm:p-4 pb-28">
        <div className="max-w-2xl mx-auto" />
      </div>
    )
  }

  const selectedDivision =
    selected?.type === 'division' ? divisions.find((d) => d.id === selected.id) || null : null
  const selectedDepartment =
    selected?.type === 'department' ? departments.find((d) => d.id === selected.id) || null : null
  const parentDivisionOfSelectedDept = selectedDepartment
    ? divisions.find((d) => d.id === selectedDepartment.division_id) || null
    : null
  const selectedTeam =
    selected?.type === 'team' ? teams.find((t) => t.id === selected.id) || null : null
  const parentDeptOfSelectedTeam = selectedTeam
    ? departments.find((d) => d.id === selectedTeam.department_id) || null
    : null
  const parentDivOfSelectedTeamDept = parentDeptOfSelectedTeam
    ? divisions.find((d) => d.id === parentDeptOfSelectedTeam.division_id) || null
    : null

  // ============ 상세 패널 렌더 함수 (데스크탑/모바일 공용) ============
  function renderUnassignedDetail() {
    const myDepts = assignableDepartments()
    const leadTeams = myLeadTeams()
    return (
      <div>
        <div className="flex items-center gap-2 flex-wrap mb-1">
          <h2 className="text-lg font-semibold dark:text-white">미지정 인원</h2>
          <span className="text-sm text-gray-500 dark:text-zinc-400 shrink-0">
            {unassignedProfiles.length}명
          </span>
        </div>
        <p className="text-sm text-gray-500 dark:text-zinc-400 mb-4">
          어느 팀이나 부서에도 소속되지 않은 인원이에요. 내가 관리하는 조직으로 배정할 수 있어요.
        </p>

        {unassignedProfiles.length === 0 && (
          <p className="text-sm text-gray-500 dark:text-zinc-400 text-center py-6">
            미지정 인원이 없어요.
          </p>
        )}

        <div className="space-y-2">
          {unassignedProfiles.map((p) => (
            <div
              key={p.id}
              className="flex items-center justify-between gap-2 bg-gray-50 dark:bg-zinc-900/40 rounded-lg px-4 py-3"
            >
              <span className="text-sm font-medium dark:text-white truncate">{p.name}</span>
              {myDepts.length === 0 && leadTeams.length === 0 ? (
                <span className="text-[11px] text-gray-300 dark:text-zinc-600 shrink-0">
                  배정 권한 없음
                </span>
              ) : assigningId === p.id ? (
                myDepts.length > 0 ? (
                  <MoveForm
                    departmentsForActor={myDepts}
                    moveTargetDept={assignTargetDept}
                    setMoveTargetDept={setAssignTargetDept}
                    moveTargetTeam={assignTargetTeam}
                    setMoveTargetTeam={setAssignTargetTeam}
                    teamsInDept={teamsInDept}
                    onConfirm={() => handleConfirmAssign(p.id)}
                    onCancel={closeAssign}
                  />
                ) : (
                  // 부서/부문 권한 없이 팀장 권한만 있는 경우: 부서 선택 없이 자기 팀 중에서만 고른다
                  <span className="inline-flex flex-wrap items-center gap-1 max-w-full">
                    <select
                      value={assignTargetTeam}
                      onChange={(e) => setAssignTargetTeam(e.target.value)}
                      className="border rounded-lg px-1.5 py-0.5 text-[11px] dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200 max-w-[40vw] sm:max-w-[160px]"
                    >
                      {leadTeams.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name}
                        </option>
                      ))}
                    </select>
                    <button
                      onClick={() => handleConfirmAssign(p.id)}
                      className="text-[11px] text-green-500 font-medium shrink-0 px-1 py-0.5"
                    >
                      확인
                    </button>
                    <button
                      onClick={closeAssign}
                      className="text-[11px] text-gray-400 shrink-0 px-1 py-0.5"
                    >
                      취소
                    </button>
                  </span>
                )
              ) : (
                <button
                  onClick={() => openAssign(p.id)}
                  className="text-xs text-blue-500 hover:underline font-medium shrink-0"
                >
                  + 배정
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    )
  }

  function renderDivisionDetail(division: DivisionRow, mobile = false) {
    const canManageThisDivision = canManageDivision(user.id, division.id, divisions, hasTopAccess)
    const deptList = departmentsOfDivision(division.id)
    const isReorderingDepts = reorder?.kind === 'departments' && reorder.divisionId === division.id
    const headKey = `div-head-${division.id}`

    return (
      <div>
        <div className="flex items-start justify-between mb-1 gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-semibold dark:text-white truncate">{division.name}</h2>
            </div>
            <p className="text-sm text-gray-500 dark:text-zinc-400 mt-0.5">
              {division.head_user_id ? `부문장 ${profileName(division.head_user_id)}` : '부문장 공석'} · 총{' '}
              {headcountOfDivision(division.id)}명
            </p>
          </div>
          <div className={`flex items-center gap-1.5 relative shrink-0 ${dimClass(!reorder)}`}>
            {(hasTopAccess || canManageThisDivision) && (
              <>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    setMenuOpenId(menuOpenId === `div-${division.id}` ? null : `div-${division.id}`)
                  }}
                  className="text-gray-500 dark:text-zinc-400 px-1.5 py-1.5"
                >
                  ⋮
                </button>
                {menuOpenId === `div-${division.id}` && (
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="absolute right-0 top-9 bg-white dark:bg-zinc-800 border border-gray-100 dark:border-zinc-700 rounded-lg shadow-lg py-1 w-36 z-10"
                  >
                    {hasTopAccess && (
                      <button
                        onClick={() => {
                          setMenuOpenId(null)
                          openModal({ kind: 'assignDivisionHead', divisionId: division.id })
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs text-gray-600 dark:text-zinc-300 hover:bg-gray-50 dark:hover:bg-zinc-700"
                      >
                        부문장 변경
                      </button>
                    )}
                    {canManageThisDivision && deptList.length > 1 && (
                      <button
                        onClick={() => startReorderDepartments(division.id)}
                        className="w-full text-left px-3 py-1.5 text-xs text-gray-600 dark:text-zinc-300 hover:bg-gray-50 dark:hover:bg-zinc-700"
                      >
                        순서 변경
                      </button>
                    )}
                    {hasTopAccess && (
                      <button
                        onClick={() => {
                          setMenuOpenId(null)
                          confirmDeleteDivision(division)
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"
                      >
                        부문 삭제
                      </button>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        <div className={dimClass(!reorder)}>
          <TabBar
            tabs={[
              { key: 'structure', label: '부서' },
              { key: 'members', label: '구성원' },
              { key: 'permissions', label: '권한 관리' },
            ]}
            active={activeTab}
            onChange={(k) => setActiveTab(k as TabKey)}
          />
        </div>

        {activeTab === 'structure' && (
          <div>
            <div className="flex justify-between items-center mb-3">
              {isReorderingDepts ? (
                <p className="text-xs text-blue-500 font-medium">순서를 드래그해서 바꿔보세요.</p>
              ) : (
                <span />
              )}
              {isReorderingDepts && (
                <span className="flex items-center gap-3">
                  <button
                    onClick={cancelReorder}
                    className="text-xs text-gray-500 dark:text-zinc-400 hover:underline"
                  >
                    취소
                  </button>
                  <Button size="sm" onClick={finishReorder}>
                    완료
                  </Button>
                </span>
              )}
            </div>
            {deptList.length === 0 && (
              <p className="text-sm text-gray-500 dark:text-zinc-400 text-center py-6">
                등록된 부서가 없어요.
              </p>
            )}
            <div className={`space-y-2 ${dimClass(!reorder || isReorderingDepts)}`}>
              <DragList
                items={deptList}
                getKey={(d) => d.id}
                disabled={!isReorderingDepts}
                onReorder={(next) =>
                  setDepartments((prev) =>
                    replaceGroup(prev, (d) => d.division_id === division.id, next)
                  )
                }
                renderItem={(department) =>
                  isReorderingDepts ? (
                    <div className="w-full flex items-center justify-between bg-gray-50 dark:bg-zinc-900/40 rounded-lg px-4 py-3">
                      <div className="min-w-0">
                        <p className="font-semibold text-sm dark:text-white truncate">
                          {department.name}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-zinc-400 mt-0.5">
                          {department.head_user_id ? `부장 ${profileName(department.head_user_id)}` : '부장 공석'} ·{' '}
                          {headcountOfDept(department.id)}명
                        </p>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => selectDepartment(department.id)}
                      className="w-full flex items-center justify-between bg-gray-50 dark:bg-zinc-900/40 hover:bg-gray-100 dark:hover:bg-zinc-900/70 rounded-lg px-4 py-3 text-left transition"
                    >
                      <div className="min-w-0">
                        <p className="font-semibold text-sm dark:text-white truncate">
                          {department.name}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-zinc-400 mt-0.5">
                          {department.head_user_id ? `부장 ${profileName(department.head_user_id)}` : '부장 공석'} ·{' '}
                          {headcountOfDept(department.id)}명
                        </p>
                      </div>
                      <span className="text-gray-300 dark:text-zinc-600 shrink-0 ml-2">›</span>
                    </button>
                  )
                }
              />
            </div>
            {canManageThisDivision && !reorder && (
              <button
                onClick={() => openModal({ kind: 'createDepartment', divisionId: division.id })}
                className="w-full mt-3 border border-dashed border-gray-200 dark:border-zinc-700 text-gray-500 dark:text-zinc-400 py-2.5 rounded-lg text-sm font-medium"
              >
                + 부서 생성
              </button>
            )}
          </div>
        )}

        {activeTab === 'members' && (
          <div className={`space-y-4 ${dimClass(!reorder)}`}>
            {division.head_user_id && (
              <div>
                <p className="text-xs font-semibold text-gray-500 dark:text-zinc-400 mb-1.5">
                  부문장
                </p>
                <div className="border-t border-gray-100 dark:border-zinc-800" />
                <div className="relative flex items-center flex-wrap justify-between gap-y-1 gap-x-2 py-1">
                  <span className="text-sm font-medium dark:text-white truncate">
                    {profileName(division.head_user_id)}
                  </span>
                  <MemberActionMenu
                    rowKey={headKey}
                    openKey={openActionKey}
                    setOpenKey={setOpenActionKey}
                    movingKey={movingKey}
                    canMove={hasTopAccess}
                    canRemove={
                      hasTopAccess &&
                      directMembers.some((m) => m.user_id === division.head_user_id)
                    }
                    onMoveClick={() =>
                      openMove(
                        headKey,
                        directMembers.find((m) => m.user_id === division.head_user_id)
                          ?.department_id ||
                          deptList[0]?.id ||
                          '',
                        null
                      )
                    }
                    onRemoveClick={() =>
                      confirmUnassignFromDept(
                        directMembers.find((m) => m.user_id === division.head_user_id)
                          ?.department_id || '',
                        division.head_user_id as string
                      )
                    }
                    moveForm={
                      <MoveForm
                        departmentsForActor={departmentsForActor(division, deptList[0]?.id || '')}
                        moveTargetDept={moveTargetDept}
                        setMoveTargetDept={setMoveTargetDept}
                        moveTargetTeam={moveTargetTeam}
                        setMoveTargetTeam={setMoveTargetTeam}
                        teamsInDept={teamsInDept}
                        onConfirm={() =>
                          handleConfirmMove(
                            division.head_user_id as string,
                            null,
                            directMembers.find((m) => m.user_id === division.head_user_id)
                              ?.department_id || ''
                          )
                        }
                        onCancel={closeMove}
                      />
                    }
                  />
                </div>
              </div>
            )}
            {deptList.length === 0 && (
              <p className="text-sm text-gray-500 dark:text-zinc-400 text-center py-6">
                등록된 부서가 없어요.
              </p>
            )}
            {deptList.map((department) => {
              // 부서장은 이미 위 배지에서 다룰 수 있으므로(우선순위 표시, req 11) 직속 목록에서는 중복 노출하지 않는다.
              const directs = directOfDept(department.id).filter(
                (m) => m.user_id !== department.head_user_id
              )
              const deptTeams = teamsInDept(department.id)
              const teamMembersFlat = deptTeams.flatMap((t) => membersOfTeam(t.id))
              const headEntry = department.head_user_id
                ? directOfDept(department.id).find((m) => m.user_id === department.head_user_id)
                : null
              const canManageThisDeptRow = canManageDepartment(
                user.id,
                department.id,
                departments,
                divisions,
                hasTopAccess
              )
              return (
                <div key={department.id}>
                  <div className="w-full flex items-center justify-between gap-2 mb-1.5">
                    <span className="text-sm font-semibold text-gray-700 dark:text-zinc-200 truncate">
                      {department.name}
                    </span>
                    <span className="text-xs text-gray-500 dark:text-zinc-400 shrink-0">
                      ({headcountOfDept(department.id)}명)
                    </span>
                  </div>
                  <div className="border-t border-gray-100 dark:border-zinc-800" />
                  <div className="divide-y divide-gray-50 dark:divide-zinc-900/60">
                    {headEntry && (
                      <div className="relative flex items-center flex-wrap justify-between gap-y-1 gap-x-2 py-1">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="text-sm font-medium dark:text-white truncate">
                            {headEntry.name}
                          </span>
                          <span className="text-[11px] text-blue-500 shrink-0">부서장</span>
                        </div>
                        <MemberActionMenu
                          rowKey={`div-direct-${department.id}-${headEntry.user_id}`}
                          openKey={openActionKey}
                          setOpenKey={setOpenActionKey}
                          movingKey={movingKey}
                          canMove={canManageThisDeptRow}
                          canRemove={canManageThisDeptRow}
                          onMoveClick={() =>
                            openMove(
                              `div-direct-${department.id}-${headEntry.user_id}`,
                              department.id,
                              null
                            )
                          }
                          onRemoveClick={() =>
                            confirmUnassignFromDept(department.id, headEntry.user_id)
                          }
                          moveForm={
                            <MoveForm
                              departmentsForActor={departmentsForActor(division, department.id)}
                              moveTargetDept={moveTargetDept}
                              setMoveTargetDept={setMoveTargetDept}
                              moveTargetTeam={moveTargetTeam}
                              setMoveTargetTeam={setMoveTargetTeam}
                              teamsInDept={teamsInDept}
                              onConfirm={() =>
                                handleConfirmMove(headEntry.user_id, null, department.id)
                              }
                              onCancel={closeMove}
                            />
                          }
                        />
                      </div>
                    )}
                    {directs.map((m) => (
                      <div key={m.user_id} className="relative flex items-center flex-wrap justify-between gap-y-1 gap-x-2 py-1">
                        <span className="text-sm text-gray-600 dark:text-zinc-300 truncate">
                          {m.name}
                        </span>
                        <MemberActionMenu
                          rowKey={`div-direct-${department.id}-${m.user_id}`}
                          openKey={openActionKey}
                          setOpenKey={setOpenActionKey}
                          movingKey={movingKey}
                          canMove={canManageThisDeptRow}
                          canRemove={canManageThisDeptRow}
                          onMoveClick={() =>
                            openMove(`div-direct-${department.id}-${m.user_id}`, department.id, null)
                          }
                          onRemoveClick={() => confirmUnassignFromDept(department.id, m.user_id)}
                          moveForm={
                            <MoveForm
                              departmentsForActor={departmentsForActor(division, department.id)}
                              moveTargetDept={moveTargetDept}
                              setMoveTargetDept={setMoveTargetDept}
                              moveTargetTeam={moveTargetTeam}
                              setMoveTargetTeam={setMoveTargetTeam}
                              teamsInDept={teamsInDept}
                              onConfirm={() => handleConfirmMove(m.user_id, null, department.id)}
                              onCancel={closeMove}
                            />
                          }
                        />
                      </div>
                    ))}
                    {teamMembersFlat.map((m) => (
                      <div
                        key={`${m.team_id}-${m.user_id}`}
                        className="relative flex items-center flex-wrap justify-between gap-y-1 gap-x-2 py-1"
                      >
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="text-sm text-gray-600 dark:text-zinc-300 truncate">
                            {m.name}
                          </span>
                          {m.role === 'admin' && (
                            <span className="text-[11px] text-blue-500 shrink-0">팀장</span>
                          )}
                        </div>
                        <MemberActionMenu
                          rowKey={`div-team-${m.team_id}-${m.user_id}`}
                          openKey={openActionKey}
                          setOpenKey={setOpenActionKey}
                          movingKey={movingKey}
                          canMove={canManageThisDeptRow}
                          canRemove={canManageThisDeptRow}
                          onMoveClick={() =>
                            openMove(`div-team-${m.team_id}-${m.user_id}`, department.id, m.team_id)
                          }
                          onRemoveClick={() => confirmUnassignFromTeam(m.team_id, m.user_id)}
                          moveForm={
                            <MoveForm
                              departmentsForActor={departmentsForActor(division, department.id)}
                              moveTargetDept={moveTargetDept}
                              setMoveTargetDept={setMoveTargetDept}
                              moveTargetTeam={moveTargetTeam}
                              setMoveTargetTeam={setMoveTargetTeam}
                              teamsInDept={teamsInDept}
                              onConfirm={() =>
                                handleConfirmMove(m.user_id, m.team_id, department.id)
                              }
                              onCancel={closeMove}
                            />
                          }
                        />
                      </div>
                    ))}
                    {!headEntry && directs.length === 0 && teamMembersFlat.length === 0 && (
                      <p className="text-[11px] text-gray-300 dark:text-zinc-600 py-2">
                        소속 인원 없음
                      </p>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {activeTab === 'permissions' && (
          <div className="space-y-5">
            {/* 부문장은 부문 산하 모든 부서에 대한 결재권을 가진다 (부서장의 결재가 부문장에게 올라감).
                부서장과 같은 패턴으로 부문장도 결재권자를 위임할 수 있다. */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-gray-500 dark:text-zinc-400">
                  결재권자
                </p>
                {canManageThisDivision && (
                  <button
                    onClick={() =>
                      openModal({ kind: 'addApprover', scope: 'division', targetId: division.id })
                    }
                    className="text-xs text-blue-500 hover:underline font-medium"
                  >
                    + 결재권자 위임
                  </button>
                )}
              </div>
              <div className="space-y-0.5">
                <ApproverRow
                  name={profileName(division.head_user_id) || '부문장 공석'}
                  meta="부문장(자동)"
                />
                {approversOfDivision(division.id).map((a) => (
                  <ApproverRow
                    key={a.id}
                    name={a.name}
                    scopes={[
                      a.can_vacation && '휴가',
                      a.can_remote && '원격',
                      a.can_holiday && '휴일',
                    ].filter((v): v is string => Boolean(v))}
                    onRemove={
                      canManageThisDivision
                        ? () => confirmRemoveApprover('division', a.id)
                        : undefined
                    }
                  />
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  function renderDepartmentDetail(
    department: DepartmentRow,
    division: DivisionRow,
    mobile = false
  ) {
    const canManageThisDept = canManageDepartment(
      user.id,
      department.id,
      departments,
      divisions,
      hasTopAccess
    )
    const canManageThisDivision = canManageDivision(user.id, division.id, divisions, hasTopAccess)
    const deptTeams = teamsInDept(department.id)
    const directs = directOfDept(department.id)
    // 구조 탭의 "부서 직속" 펼침 목록 전용 — 부서장 최상단 + 저장된 순서 반영
    const directsOrdered = orderedDirectsOfDept(department)
    const delegates = approversOfDept(department.id)
    const isReorderingTeams = reorder?.kind === 'teams' && reorder.departmentId === department.id
    const isReorderingMembers =
      reorder?.kind === 'deptMembers' && reorder.departmentId === department.id
    const headKey = `dept-head-${department.id}`

    return (
      <div>
        {!mobile && (
          <button
            onClick={() => selectDivision(division.id)}
            className={`text-xs text-gray-300 dark:text-zinc-600 mb-1 hover:underline ${dimClass(!reorder)}`}
          >
            {division.name}
          </button>
        )}
        <div className="flex items-start justify-between mb-1 gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-semibold dark:text-white truncate">{department.name}</h2>
            </div>
            <p className="text-sm text-gray-500 dark:text-zinc-400 mt-0.5">
              {department.head_user_id ? `부장 ${profileName(department.head_user_id)}` : '부장 공석'} · 총{' '}
              {headcountOfDept(department.id)}명
            </p>
          </div>
          <div className={`flex items-center gap-1.5 relative shrink-0 ${dimClass(!reorder)}`}>
            {(canManageThisDivision || canManageThisDept) && (
              <>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    setMenuOpenId(
                      menuOpenId === `dept-${department.id}` ? null : `dept-${department.id}`
                    )
                  }}
                  className="text-gray-500 dark:text-zinc-400 px-1.5 py-1.5"
                >
                  ⋮
                </button>
                {menuOpenId === `dept-${department.id}` && (
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="absolute right-0 top-9 bg-white dark:bg-zinc-800 border border-gray-100 dark:border-zinc-700 rounded-lg shadow-lg py-1 w-36 z-10"
                  >
                    {canManageThisDivision && (
                      <button
                        onClick={() => {
                          setMenuOpenId(null)
                          openModal({ kind: 'assignDepartmentHead', departmentId: department.id })
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs text-gray-600 dark:text-zinc-300 hover:bg-gray-50 dark:hover:bg-zinc-700"
                      >
                        부서장 변경
                      </button>
                    )}
                    {canManageThisDept && deptTeams.length > 1 && (
                      <button
                        onClick={() => startReorderTeams(department.id)}
                        className="w-full text-left px-3 py-1.5 text-xs text-gray-600 dark:text-zinc-300 hover:bg-gray-50 dark:hover:bg-zinc-700"
                      >
                        팀 순서 변경
                      </button>
                    )}
                    {canManageThisDept &&
                      directs.length +
                        deptTeams.reduce((acc, t) => acc + membersOfTeam(t.id).length, 0) >
                        1 && (
                        <button
                          onClick={() => startReorderDeptMembers(department.id)}
                          className="w-full text-left px-3 py-1.5 text-xs text-gray-600 dark:text-zinc-300 hover:bg-gray-50 dark:hover:bg-zinc-700"
                        >
                          구성원 순서 변경
                        </button>
                      )}
                    {canManageThisDivision && (
                      <button
                        onClick={() => {
                          setMenuOpenId(null)
                          confirmDeleteDepartment(department)
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"
                      >
                        부서 삭제
                      </button>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        <div className={dimClass(!reorder)}>
          <TabBar
            tabs={[
              { key: 'structure', label: '팀' },
              { key: 'members', label: '구성원' },
              { key: 'permissions', label: '권한 관리' },
            ]}
            active={activeTab}
            onChange={(k) => setActiveTab(k as TabKey)}
          />
        </div>

        {activeTab === 'structure' && (
          <div>
            {isReorderingTeams && (
              <div className="flex justify-between items-center mb-3">
                <p className="text-xs text-blue-500 font-medium">
                  팀 순서를 드래그해서 바꿔보세요.
                </p>
                <span className="flex items-center gap-3">
                  <button
                    onClick={cancelReorder}
                    className="text-xs text-gray-500 dark:text-zinc-400 hover:underline"
                  >
                    취소
                  </button>
                  <Button size="sm" onClick={finishReorder}>
                    완료
                  </Button>
                </span>
              </div>
            )}

            {/* 부서 직속: 팀보다 상위 개념이므로 팀 목록과 같은 카드 형식으로, 가장 먼저 보여준다 (순서변경 대상 아님) */}
            <div className={`mb-2 ${dimClass(!isReorderingTeams)}`}>
              <button
                onClick={() =>
                  setOpenStructureItem(openStructureItem === 'direct' ? null : 'direct')
                }
                className="w-full flex items-center justify-between bg-gray-50 dark:bg-zinc-900/40 hover:bg-gray-100 dark:hover:bg-zinc-900/70 rounded-lg px-4 py-3 text-left transition"
              >
                <div className="min-w-0">
                  <p className="font-semibold text-sm dark:text-white truncate">부서 직속</p>
                  <p className="text-xs text-gray-500 dark:text-zinc-400 mt-0.5">
                    {directsOrdered.length}명
                  </p>
                </div>
                <span className="text-gray-300 dark:text-zinc-600 shrink-0 ml-2">
                  {openStructureItem === 'direct' ? '⌄' : '›'}
                </span>
              </button>
              {openStructureItem === 'direct' && (
                <div className="mt-1.5 px-4 py-3 bg-gray-50/60 dark:bg-zinc-900/20 rounded-lg">
                  {directsOrdered.length === 0 ? (
                    <p className="text-xs text-gray-300 dark:text-zinc-600">
                      소속된 인원이 없어요.
                    </p>
                  ) : (
                    <div className="space-y-1.5">
                      {/* 이동/내보내기는 "구성원" 탭에서만 할 수 있다 — 팀 구조 탭의 부서 직속
                          펼침 목록은 보기 전용이다. */}
                      {directsOrdered.map((d) => {
                        const key = `direct-${department.id}-${d.user_id}`
                        return (
                          <div
                            key={key}
                            className="flex items-center gap-2 flex-wrap text-sm text-gray-600 dark:text-zinc-300"
                          >
                            <span>{d.name}</span>
                            {d.user_id === department.head_user_id && (
                              <span className="text-[11px] text-blue-500">부서장</span>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>

            {deptTeams.length === 0 && (
              <p className="text-sm text-gray-500 dark:text-zinc-400 text-center py-4">
                등록된 팀이 없어요.
              </p>
            )}
            <div className="space-y-2">
              <DragList
                items={deptTeams}
                getKey={(t) => t.id}
                disabled={!isReorderingTeams}
                onReorder={(next) =>
                  setTeams((prev) =>
                    replaceGroup(prev, (t) => t.department_id === department.id, next)
                  )
                }
                renderItem={(team) => {
                  const members = membersOfTeam(team.id)
                  const lead = teamLeadOf(team.id)
                  return isReorderingTeams ? (
                    <div className="w-full flex items-center justify-between bg-gray-50 dark:bg-zinc-900/40 rounded-lg px-4 py-3">
                      <div className="min-w-0">
                        <p className="font-semibold text-sm dark:text-white truncate">
                          {team.name}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-zinc-400 mt-0.5">
                          {lead ? `팀장 ${lead.name}` : '팀장 공석'} · {members.length}명
                        </p>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => selectTeam(team.id)}
                      className="w-full flex items-center justify-between bg-gray-50 dark:bg-zinc-900/40 hover:bg-gray-100 dark:hover:bg-zinc-900/70 rounded-lg px-4 py-3 text-left transition"
                    >
                      <div className="min-w-0">
                        <p className="font-semibold text-sm dark:text-white truncate">
                          {team.name}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-zinc-400 mt-0.5">
                          {lead ? `팀장 ${lead.name}` : '팀장 공석'} · {members.length}명
                        </p>
                      </div>
                      <span className="text-gray-300 dark:text-zinc-600 shrink-0 ml-2">›</span>
                    </button>
                  )
                }}
              />
            </div>

            {canManageThisDept && !reorder && (
              <button
                onClick={() => openModal({ kind: 'createTeam', departmentId: department.id })}
                className="w-full mt-4 border border-dashed border-gray-200 dark:border-zinc-700 text-gray-500 dark:text-zinc-400 py-2.5 rounded-lg text-sm font-medium"
              >
                + 팀 생성
              </button>
            )}
          </div>
        )}

        {activeTab === 'members' && (
          <div className={`space-y-4 ${dimClass(!reorder || isReorderingMembers)}`}>
            {isReorderingMembers && (
              <div className="flex justify-between items-center -mt-1">
                <p className="text-xs text-blue-500 font-medium">
                  각 목록 안에서 순서를 드래그해서 바꿔보세요.
                </p>
                <span className="flex items-center gap-3">
                  <button
                    onClick={cancelReorder}
                    className="text-xs text-gray-500 dark:text-zinc-400 hover:underline"
                  >
                    취소
                  </button>
                  <Button size="sm" onClick={finishReorder}>
                    완료
                  </Button>
                </span>
              </div>
            )}
            <div>
              {/*
                부서장도 부서 직속 구성원이다 — 별도 "부서장" 섹션으로 빼서 부서 직속 목록에서
                제외하면(구 로직) 부서 직속 인원이 부서장뿐일 때 "없음"으로 잘못 표시되고, 인원수도
                실제 데이터와 어긋난다. 부서장을 포함한 하나의 "부서 직속" 목록으로 통일하고,
                부서장은 배지로만 구분한다. (부서장은 항상 최상단에 고정 — lib/orgOrder의 규칙과 동일)
                이동/내보내기는 이름과 같은 행 오른쪽 끝의 ⋮ 버튼을 눌렀을 때만 펼쳐진다.
              */}
              {(() => {
                const headInDirects = department.head_user_id
                  ? directs.some((d) => d.user_id === department.head_user_id)
                  : false
                // department_memberships에 부서장이 없더라도(자리만 있는 경우) 목록/인원수에는 포함한다.
                const directsAll =
                  department.head_user_id && !headInDirects
                    ? [
                        {
                          user_id: department.head_user_id,
                          name: profileName(department.head_user_id) || '알 수 없음',
                          department_id: department.id,
                        },
                        ...directs,
                      ]
                    : directs
                const headEntry = department.head_user_id
                  ? directsAll.find((d) => d.user_id === department.head_user_id) || null
                  : null
                const restEntries = directsAll.filter(
                  (d) => d.user_id !== department.head_user_id
                )

                const renderRow = (
                  d: MemberRow & { department_id: string },
                  isHead: boolean
                ) => {
                  const rowKey = isHead ? headKey : `direct-${department.id}-${d.user_id}`
                  const canManageRow = isHead ? canManageThisDivision : canManageThisDept
                  return (
                    <div className="relative flex items-center flex-wrap justify-between gap-y-1 gap-x-2 py-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span
                          className={`text-sm truncate ${
                            isHead ? 'font-medium dark:text-white' : 'text-gray-600 dark:text-zinc-300'
                          }`}
                        >
                          {d.name}
                        </span>
                        {isHead && <span className="text-[11px] text-blue-500 shrink-0">부서장</span>}
                      </div>
                      {!isReorderingMembers && (
                        <MemberActionMenu
                          rowKey={rowKey}
                          openKey={openActionKey}
                          setOpenKey={setOpenActionKey}
                          movingKey={movingKey}
                          canMove={canManageRow}
                          canRemove={canManageRow}
                          onMoveClick={() => openMove(rowKey, department.id, null)}
                          onRemoveClick={() => confirmUnassignFromDept(department.id, d.user_id)}
                          moveForm={
                            <MoveForm
                              departmentsForActor={departmentsForActor(division, department.id)}
                              moveTargetDept={moveTargetDept}
                              setMoveTargetDept={setMoveTargetDept}
                              moveTargetTeam={moveTargetTeam}
                              setMoveTargetTeam={setMoveTargetTeam}
                              teamsInDept={teamsInDept}
                              onConfirm={() => handleConfirmMove(d.user_id, null, department.id)}
                              onCancel={closeMove}
                            />
                          }
                        />
                      )}
                    </div>
                  )
                }

                return (
                  <>
                    <div className="flex items-center justify-between mb-1.5">
                      <p className="text-sm font-semibold text-gray-700 dark:text-zinc-200">
                        부서 직속
                      </p>
                      <span className="text-xs text-gray-500 dark:text-zinc-400">
                        ({directsAll.length}명)
                      </span>
                    </div>
                    <div className="border-t border-gray-100 dark:border-zinc-800" />
                    {directsAll.length === 0 ? (
                      <p className="text-xs text-gray-300 dark:text-zinc-600 py-2">없음</p>
                    ) : (
                      <div className="divide-y divide-gray-50 dark:divide-zinc-900/60">
                        {headEntry && (
                          <div className={dimClass(!isReorderingMembers)}>
                            {renderRow(headEntry, true)}
                          </div>
                        )}
                        <DragList
                          items={restEntries}
                          getKey={(d) => d.user_id}
                          disabled={!isReorderingMembers}
                          onReorder={(next) =>
                            setDirectMembers((prev) =>
                              replaceGroup(
                                prev,
                                (m) =>
                                  m.department_id === department.id &&
                                  m.user_id !== department.head_user_id,
                                next
                              )
                            )
                          }
                          renderItem={(d) => renderRow(d, false)}
                        />
                      </div>
                    )}
                  </>
                )
              })()}
            </div>

            {deptTeams.map((team) => {
              const members = membersOfTeam(team.id)
              if (members.length === 0) return null
              return (
                <div key={team.id}>
                  <div className="flex items-center justify-between mb-1.5">
                    <p className="text-sm font-semibold text-gray-700 dark:text-zinc-200">
                      {team.name}
                    </p>
                    <span className="text-xs text-gray-500 dark:text-zinc-400">
                      ({members.length}명)
                    </span>
                  </div>
                  <div className="border-t border-gray-100 dark:border-zinc-800" />
                  <div className="divide-y divide-gray-50 dark:divide-zinc-900/60">
                    <DragList
                      items={members}
                      getKey={(m) => m.user_id}
                      disabled={!isReorderingMembers}
                      onReorder={(next) =>
                        setTeamMembers((prev) =>
                          replaceGroup(prev, (m) => m.team_id === team.id, next)
                        )
                      }
                      renderItem={(m) => {
                        const rowKey = `team-${team.id}-${m.user_id}`
                        return (
                          <div className="relative flex items-center flex-wrap justify-between gap-y-1 gap-x-2 py-1">
                            <div className="flex items-center gap-1.5 min-w-0">
                              <span className="text-sm text-gray-600 dark:text-zinc-300 truncate">
                                {m.name}
                              </span>
                              {m.role === 'admin' && (
                                <span className="text-[11px] text-blue-500 shrink-0">팀장</span>
                              )}
                            </div>
                            {!isReorderingMembers && (
                              <MemberActionMenu
                                rowKey={rowKey}
                                openKey={openActionKey}
                                setOpenKey={setOpenActionKey}
                                movingKey={movingKey}
                                canMove={canManageThisDept}
                                canRemove={canManageThisDept}
                                onMoveClick={() => openMove(rowKey, department.id, team.id)}
                                onRemoveClick={() => confirmUnassignFromTeam(team.id, m.user_id)}
                                moveForm={
                                  <MoveForm
                                    departmentsForActor={departmentsForActor(division, department.id)}
                                    moveTargetDept={moveTargetDept}
                                    setMoveTargetDept={setMoveTargetDept}
                                    moveTargetTeam={moveTargetTeam}
                                    setMoveTargetTeam={setMoveTargetTeam}
                                    teamsInDept={teamsInDept}
                                    onConfirm={() =>
                                      handleConfirmMove(m.user_id, team.id, department.id)
                                    }
                                    onCancel={closeMove}
                                  />
                                }
                              />
                            )}
                          </div>
                        )
                      }}
                    />
                  </div>
                </div>
              )
            })}

            {deptTeams.every((t) => membersOfTeam(t.id).length === 0) && directs.length === 0 && (
              <p className="text-sm text-gray-500 dark:text-zinc-400 text-center py-4">
                소속된 구성원이 없어요.
              </p>
            )}
          </div>
        )}

        {activeTab === 'permissions' && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-gray-500 dark:text-zinc-400">결재권자</p>
              {canManageThisDept && (
                <button
                  onClick={() =>
                    openModal({ kind: 'addApprover', scope: 'department', targetId: department.id })
                  }
                  className="text-xs text-blue-500 hover:underline font-medium"
                >
                  + 결재권자 위임
                </button>
              )}
            </div>
            <div className="space-y-0.5">
              <ApproverRow
                name={profileName(department.head_user_id) || '부서장 공석'}
                meta="부장(자동)"
              />
              {delegates.map((a) => (
                <ApproverRow
                  key={a.id}
                  name={a.name}
                  scopes={[
                    a.can_vacation && '휴가',
                    a.can_remote && '원격',
                    a.can_holiday && '휴일',
                  ].filter((v): v is string => Boolean(v))}
                  onRemove={
                    canManageThisDept ? () => confirmRemoveApprover('department', a.id) : undefined
                  }
                />
              ))}
            </div>
          </div>
        )}
      </div>
    )
  }

  function renderTeamDetail(
    team: TeamRow,
    department: DepartmentRow,
    division: DivisionRow,
    mobile = false
  ) {
    const canManageThisDept = canManageDepartment(
      user.id,
      department.id,
      departments,
      divisions,
      hasTopAccess
    )
    // 팀장은 팀 구조 변경(팀장 교체/팀 삭제)까지는 못 하지만, 자기 팀의 권한 관리(결재권자 위임)와
    // 자기 권한 아래 있는 팀원 관리(내보내기)는 부서장과 동등하게 할 수 있다.
    const canManageThisTeam = canManageTeam(
      user.id,
      team.id,
      department.id,
      teamMembers,
      departments,
      divisions,
      hasTopAccess
    )
    const members = membersOfTeam(team.id)
    const lead = teamLeadOf(team.id)

    return (
      <div>
        {!mobile && (
          <button
            onClick={() => selectDepartment(department.id)}
            className="text-xs text-gray-300 dark:text-zinc-600 mb-1 hover:underline"
          >
            {department.name}
          </button>
        )}
        <div className="flex items-start justify-between mb-1 gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-semibold dark:text-white truncate">{team.name}</h2>
            </div>
            <p className="text-sm text-gray-500 dark:text-zinc-400 mt-0.5">
              {lead ? `팀장 ${lead.name}` : '팀장 공석'} · 총 {members.length}명
            </p>
          </div>
          <div className="flex items-center gap-1.5 relative shrink-0">
            {canManageThisDept && (
              <>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    setMenuOpenId(menuOpenId === `team-${team.id}` ? null : `team-${team.id}`)
                  }}
                  className="text-gray-500 dark:text-zinc-400 px-1.5 py-1.5"
                >
                  ⋮
                </button>
                {menuOpenId === `team-${team.id}` && (
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="absolute right-0 top-9 bg-white dark:bg-zinc-800 border border-gray-100 dark:border-zinc-700 rounded-lg shadow-lg py-1 w-32 z-10"
                  >
                    <button
                      onClick={() => {
                        setMenuOpenId(null)
                        openModal({
                          kind: 'assignTeamHead',
                          teamId: team.id,
                          departmentId: department.id,
                        })
                      }}
                      className="w-full text-left px-3 py-1.5 text-xs text-gray-600 dark:text-zinc-300 hover:bg-gray-50 dark:hover:bg-zinc-700"
                    >
                      팀장 변경
                    </button>
                    <button
                      onClick={() => {
                        setMenuOpenId(null)
                        confirmDeleteTeam(team)
                      }}
                      className="w-full text-left px-3 py-1.5 text-xs text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"
                    >
                      팀 삭제
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        <TabBar
          tabs={[
            { key: 'members', label: '구성원' },
            { key: 'permissions', label: '권한 관리' },
          ]}
          active={activeTab === 'structure' ? 'members' : activeTab}
          onChange={(k) => setActiveTab(k as TabKey)}
        />

        {activeTab !== 'permissions' && (
          <div className="divide-y divide-gray-50 dark:divide-zinc-900/60">
            {members.length === 0 && (
              <p className="text-sm text-gray-500 dark:text-zinc-400 text-center py-6">
                소속된 구성원이 없어요.
              </p>
            )}
            {members.map((m) => {
              const key = `team-${team.id}-${m.user_id}`
              // 팀 간 이동은 대상 부서 선택이 필요해 부서장 이상만 가능하고,
              // 팀장은 자기 권한 아래 있는 팀원을 팀에서 내보내는 것만 할 수 있다.
              return (
                <div key={key} className="relative flex items-center flex-wrap justify-between gap-y-1 gap-x-2 py-1">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="text-sm text-gray-600 dark:text-zinc-300 truncate">{m.name}</span>
                    {m.role === 'admin' && (
                      <span className="text-[11px] text-blue-500 shrink-0">팀장</span>
                    )}
                  </div>
                  {canManageThisTeam && (
                    <MemberActionMenu
                      rowKey={key}
                      openKey={openActionKey}
                      setOpenKey={setOpenActionKey}
                      movingKey={movingKey}
                      canMove={canManageThisDept}
                      canRemove={true}
                      onMoveClick={() => openMove(key, department.id, team.id)}
                      onRemoveClick={() => confirmUnassignFromTeam(team.id, m.user_id)}
                      moveForm={
                        <MoveForm
                          departmentsForActor={departmentsForActor(division, department.id)}
                          moveTargetDept={moveTargetDept}
                          setMoveTargetDept={setMoveTargetDept}
                          moveTargetTeam={moveTargetTeam}
                          setMoveTargetTeam={setMoveTargetTeam}
                          teamsInDept={teamsInDept}
                          onConfirm={() => handleConfirmMove(m.user_id, team.id, department.id)}
                          onCancel={closeMove}
                        />
                      }
                    />
                  )}
                </div>
              )
            })}
          </div>
        )}

        {activeTab === 'permissions' && (
          <div className="space-y-5">
            {/* 팀장도 부서장/부문장과 같은 패턴으로 결재권자를 위임할 수 있다.
                팀원들이 결재를 올릴 때 결재권자로 팀장을 선택할 수 있는 것과 짝이 되는 관리 화면. */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-gray-500 dark:text-zinc-400">결재권자</p>
                {canManageThisTeam && (
                  <button
                    onClick={() =>
                      openModal({ kind: 'addApprover', scope: 'team', targetId: team.id })
                    }
                    className="text-xs text-blue-500 hover:underline font-medium"
                  >
                    + 결재권자 위임
                  </button>
                )}
              </div>
              <div className="space-y-0.5">
                <ApproverRow name={lead ? lead.name : '팀장 공석'} meta="팀장(자동)" />
                {approversOfTeam(team.id).map((a) => (
                  <ApproverRow
                    key={a.id}
                    name={a.name}
                    scopes={[
                      a.can_vacation && '휴가',
                      a.can_remote && '원격',
                      a.can_holiday && '휴일',
                    ].filter((v): v is string => Boolean(v))}
                    onRemove={canManageThisTeam ? () => confirmRemoveApprover('team', a.id) : undefined}
                  />
                ))}
              </div>
            </div>

          </div>
        )}
      </div>
    )
  }

  return (
    <div
      className="min-h-screen bg-gray-50 dark:bg-zinc-900 p-2 sm:p-4 pb-28"
      onClick={() => setMenuOpenId(null)}
    >
      <div className="max-w-6xl mx-auto">
        {/* ---------- 헤더 ---------- */}
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-2 mb-4">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h1 className="text-xl font-semibold dark:text-white">조직 관리</h1>
            </div>
            {hasTopAccess && (
              <Button
                size="sm"
                className="md:hidden whitespace-nowrap shrink-0"
                onClick={() => openModal({ kind: 'createDivision' })}
              >
                + 부문 생성
              </Button>
            )}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {/* 모바일 관리자도 부문/부서/팀이 많아지면 스크롤 대신 검색으로 찾을 수 있어야 하므로
                더 이상 md 이상에서만 보이지 않고 항상 노출한다. */}
            <div className="relative w-full md:w-64">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-300 dark:text-zinc-600 pointer-events-none">
                <Search size={14} strokeWidth={1.75} />
              </span>
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="부문, 부서, 팀 검색"
                className="pl-8 pr-3 py-2 text-sm border border-gray-200 dark:border-zinc-700 rounded-lg w-full dark:bg-zinc-800 dark:text-zinc-200"
              />
            </div>
          </div>
        </div>

        {/* ================= 데스크탑 레이아웃 ================= */}
        <div
          className="hidden md:flex bg-white dark:bg-zinc-800 rounded-lg border border-gray-200 dark:border-zinc-700 overflow-hidden"
          style={{ minHeight: '70vh' }}
        >
          {/* 사이드바 */}
          <aside className="w-72 border-r border-gray-100 dark:border-zinc-700 flex flex-col shrink-0 min-w-0 overflow-x-hidden">
            <div className="flex-1 overflow-y-auto overflow-x-hidden py-2">
              <div className="flex items-center justify-between px-4 pt-2 pb-2">
                <p className="text-sm font-semibold text-gray-600 dark:text-zinc-300 tracking-wide">
                  조직 구조
                </p>
                {hasTopAccess && divisions.length > 1 && !reorder && (
                  <div className="relative">
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        setMenuOpenId(menuOpenId === 'org-tree' ? null : 'org-tree')
                      }}
                      className="text-gray-500 dark:text-zinc-400 px-1.5 py-0.5"
                      aria-label="더보기"
                    >
                      ⋮
                    </button>
                    {menuOpenId === 'org-tree' && (
                      <div
                        onClick={(e) => e.stopPropagation()}
                        className="absolute right-0 top-7 bg-white dark:bg-zinc-800 border border-gray-100 dark:border-zinc-700 rounded-lg shadow-lg py-1 w-28 z-10"
                      >
                        <button
                          onClick={startReorderDivisions}
                          className="w-full text-left px-3 py-1.5 text-xs text-gray-600 dark:text-zinc-300 hover:bg-gray-50 dark:hover:bg-zinc-700"
                        >
                          순서 변경
                        </button>
                      </div>
                    )}
                  </div>
                )}
                {reorder?.kind === 'divisions' && (
                  <span className="flex items-center gap-3">
                    <button
                      onClick={cancelReorder}
                      className="text-xs text-gray-500 dark:text-zinc-400 hover:underline"
                    >
                      취소
                    </button>
                    <Button size="sm" onClick={finishReorder}>
                      완료
                    </Button>
                  </span>
                )}
              </div>
              {reorder?.kind === 'divisions' ? (
                <div className="px-2 space-y-1.5">
                  <p className="px-2 pb-1 text-xs text-blue-500 font-medium">
                    순서를 드래그해서 바꿔보세요.
                  </p>
                  <DragList
                    items={divisions}
                    getKey={(d) => d.id}
                    disabled={false}
                    onReorder={(next) => setDivisions(next)}
                    renderItem={(division) => (
                      <div className="w-full flex items-center justify-between bg-gray-50 dark:bg-zinc-900/40 rounded-lg px-3 py-2.5">
                        <span className="text-sm font-medium dark:text-white truncate">
                          {division.name}
                        </span>
                        <span className="text-[11px] text-gray-300 dark:text-zinc-600 shrink-0">
                          {headcountOfDivision(division.id)}
                        </span>
                      </div>
                    )}
                  />
                </div>
              ) : (
                <>
                  {divisions.length === 0 && (
                    <p className="px-4 py-6 text-center text-xs text-gray-300 dark:text-zinc-600">
                      등록된 부문이 없어요.
                    </p>
                  )}
                  {visibleDivisions.map((division) => {
                    const isSelected = selected?.type === 'division' && selected.id === division.id
                    // 부문 이름이 검색어와 맞으면 하위 부서를 모두 보여준다 (부서 → 팀 단계와 같은 규칙).
                    const deptList = departmentsOfDivision(division.id).filter(
                      (d) => !searchTerm || matchesTerm(division.name) || departmentMatchesSearch(d)
                    )
                    const hasDepts = deptList.length > 0
                    const isOpen = hasDepts && (expandedDiv.has(division.id) || !!searchTerm)
                    return (
                      <div key={division.id} className="mx-1">
                        <TreeRow
                          level={0}
                          label={division.name}
                          count={headcountOfDivision(division.id)}
                          selected={isSelected}
                          hasChildren={hasDepts}
                          open={isOpen}
                          onClick={() => handleDivisionRowClick(division.id)}
                        />
                        {isOpen && (
                          <div className={TREE_CHILDREN_CLASS}>
                            {deptList.map((department) => {
                              const isDeptSelected =
                                selected?.type === 'department' && selected.id === department.id
                              const deptTeams = teamsInDept(department.id).filter(
                                (t) =>
                                  !searchTerm || matchesTerm(t.name) || matchesTerm(department.name)
                              )
                              const hasTeams = deptTeams.length > 0
                              const isDeptOpen =
                                hasTeams && (expandedDept.has(department.id) || !!searchTerm)
                              return (
                                <div key={department.id}>
                                  <TreeRow
                                    level={1}
                                    label={department.name}
                                    count={headcountOfDept(department.id)}
                                    selected={isDeptSelected}
                                    hasChildren={hasTeams}
                                    open={isDeptOpen}
                                    onClick={() => handleDepartmentRowClick(department.id)}
                                  />
                                  {isDeptOpen && (
                                    <div className={TREE_CHILDREN_CLASS}>
                                      {deptTeams.map((team) => (
                                        <TreeRow
                                          key={team.id}
                                          level={2}
                                          label={team.name}
                                          count={membersOfTeam(team.id).length}
                                          selected={selected?.type === 'team' && selected.id === team.id}
                                          hasChildren={false}
                                          open={false}
                                          onClick={() => selectTeam(team.id)}
                                        />
                                      ))}
                                    </div>
                                  )}
                                </div>
                              )
                            })}
                          </div>
                        )}
                      </div>
                    )
                  })}
              {visibleDivisions.length === 0 && (
                <p className="px-4 py-6 text-center text-xs text-gray-300 dark:text-zinc-600">
                  검색 결과가 없어요.
                </p>
              )}
                </>
              )}

              <div className="mt-3 pt-3 mx-1 border-t border-gray-100 dark:border-zinc-700">
                <TreeRow
                  level={0}
                  label="미지정 인원"
                  count={unassignedProfiles.length > 0 ? unassignedProfiles.length : undefined}
                  selected={selected?.type === 'unassigned'}
                  hasChildren={false}
                  open={false}
                  onClick={() => {
                    setSelected({ type: 'unassigned' })
                    setMenuOpenId(null)
                  }}
                />
              </div>
            </div>
            {hasTopAccess && !reorder && (
              <div className="p-3 border-t border-gray-100 dark:border-zinc-700">
                <Button
                  variant="tint"
                  fullWidth
                  onClick={() => openModal({ kind: 'createDivision' })}
                >
                  + 부문 생성
                </Button>
              </div>
            )}
          </aside>

          {/* 메인 패널 */}
          <main
            className="flex-1 min-w-0 overflow-y-auto overflow-x-hidden p-6"
            onClick={(e) => e.stopPropagation()}
          >
            {selected?.type === 'unassigned' && renderUnassignedDetail()}
            {selectedDivision && renderDivisionDetail(selectedDivision)}
            {selectedDepartment &&
              parentDivisionOfSelectedDept &&
              renderDepartmentDetail(selectedDepartment, parentDivisionOfSelectedDept)}
            {selectedTeam &&
              parentDeptOfSelectedTeam &&
              parentDivOfSelectedTeamDept &&
              renderTeamDetail(selectedTeam, parentDeptOfSelectedTeam, parentDivOfSelectedTeamDept)}
            {!selected && (
              <p className="text-sm text-gray-500 dark:text-zinc-400">
                왼쪽에서 부문, 부서 또는 미지정 인원을 선택해주세요.
              </p>
            )}
          </main>
        </div>

        {/* ================= 모바일 레이아웃 ================= */}
        <div className="md:hidden" onClick={(e) => e.stopPropagation()}>
          {searchTerm ? (
            /* 검색 중에는 select+드릴다운 대신, 부문/부서/팀을 가리지 않고 매칭된 항목을
               평탄한 목록으로 보여준다. 탭하면 바로 해당 상세로 이동한다. */
            <div className="bg-white dark:bg-zinc-800 rounded-lg border border-gray-200 dark:border-zinc-700 divide-y divide-gray-100 dark:divide-zinc-700 overflow-hidden">
              {mobileSearchResults.length === 0 ? (
                <p className="text-sm text-gray-500 dark:text-zinc-400 text-center py-8">
                  검색 결과가 없어요.
                </p>
              ) : (
                mobileSearchResults.map((r, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      if (r.kind === 'division') selectDivision(r.division.id)
                      else if (r.kind === 'department') selectDepartment(r.department.id)
                      else selectTeam(r.team.id)
                    }}
                    className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-gray-50 dark:hover:bg-zinc-700/50 transition"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-medium dark:text-white truncate">
                        {r.kind === 'division'
                          ? r.division.name
                          : r.kind === 'department'
                            ? r.department.name
                            : r.team.name}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-zinc-400 mt-0.5 truncate">
                        {r.kind === 'division'
                          ? '부문'
                          : r.kind === 'department'
                            ? `${r.division.name} · 부서`
                            : `${r.division.name} · ${r.department.name} · 팀`}
                      </p>
                    </div>
                    <span className="text-gray-300 dark:text-zinc-600 shrink-0 ml-2">›</span>
                  </button>
                ))
              )}
            </div>
          ) : (
            <>
              <select
                value={
                  selected?.type === 'unassigned'
                    ? '__unassigned__'
                    : selected?.type === 'team'
                      ? parentDivOfSelectedTeamDept?.id || ''
                      : selectedDepartment
                        ? selectedDepartment.division_id
                        : selectedDivision?.id || ''
                }
                onChange={(e) => {
                  if (e.target.value === '__unassigned__') setSelected({ type: 'unassigned' })
                  else selectDivision(e.target.value)
                }}
                className="w-full mb-3 border border-gray-200 dark:border-zinc-700 rounded-lg px-3 py-2.5 text-sm font-medium dark:bg-zinc-800 dark:text-zinc-200"
              >
                {divisions.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
                <option value="__unassigned__">
                  미지정 인원{' '}
                  {unassignedProfiles.length > 0 ? `(${unassignedProfiles.length})` : ''}
                </option>
              </select>

              <div className="bg-white dark:bg-zinc-800 rounded-lg border border-gray-200 dark:border-zinc-700 p-4 overflow-x-hidden">
                {selected?.type === 'unassigned' ? (
                  renderUnassignedDetail()
                ) : selected?.type === 'team' &&
                  selectedTeam &&
                  parentDeptOfSelectedTeam &&
                  parentDivOfSelectedTeamDept ? (
                  <div>
                    <button
                      onClick={() => selectDepartment(parentDeptOfSelectedTeam.id)}
                      className="mb-2 text-xs text-gray-500 dark:text-zinc-400 flex items-center gap-1"
                    >
                      ‹ {parentDeptOfSelectedTeam.name}
                    </button>
                    {renderTeamDetail(
                      selectedTeam,
                      parentDeptOfSelectedTeam,
                      parentDivOfSelectedTeamDept,
                      true
                    )}
                  </div>
                ) : selectedDepartment && parentDivisionOfSelectedDept ? (
                  <div>
                    <button
                      onClick={() => selectDivision(parentDivisionOfSelectedDept.id)}
                      className="mb-2 text-xs text-gray-500 dark:text-zinc-400 flex items-center gap-1"
                    >
                      ‹ {parentDivisionOfSelectedDept.name}
                    </button>
                    {renderDepartmentDetail(selectedDepartment, parentDivisionOfSelectedDept, true)}
                  </div>
                ) : (
                  selectedDivision && renderDivisionDetail(selectedDivision, true)
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {/* ---------- 모달 ---------- */}
      {modal && (
        <div
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 sm:p-6"
          onClick={closeModal}
        >
          <div
            className="bg-white dark:bg-zinc-800 rounded-xl shadow-lg p-6 sm:p-7 w-full max-w-md"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-semibold text-base mb-5 dark:text-white">
              {modal.kind === 'createDivision' && '부문 생성'}
              {modal.kind === 'createDepartment' && '부서 생성'}
              {modal.kind === 'createTeam' && '팀 생성'}
              {modal.kind === 'assignDivisionHead' && '부문장 지정'}
              {modal.kind === 'assignDepartmentHead' && '부서장 지정'}
              {modal.kind === 'assignTeamHead' && '팀장 지정'}
              {modal.kind === 'addApprover' && '결재권자 위임'}
            </h3>

            <div className="space-y-4">
              {(modal.kind === 'createDivision' ||
                modal.kind === 'createDepartment' ||
                modal.kind === 'createTeam') && (
                <input
                  autoFocus
                  value={modalInput}
                  onChange={(e) => setModalInput(e.target.value)}
                  placeholder="이름 입력"
                  className="w-full border rounded-lg px-3.5 py-2.5 text-sm dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200"
                />
              )}

              {(modal.kind === 'assignDivisionHead' ||
                modal.kind === 'assignDepartmentHead' ||
                modal.kind === 'assignTeamHead') && (
                <select
                  value={modalUserId}
                  onChange={(e) => setModalUserId(e.target.value)}
                  className="w-full border rounded-lg px-3.5 py-2.5 text-sm dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200"
                >
                  <option value="">공석으로</option>
                  {(modal.kind === 'assignDivisionHead'
                    ? allProfiles
                    : modal.kind === 'assignDepartmentHead'
                      ? candidatesForDivision(
                          departments.find((d) => d.id === modal.departmentId)?.division_id || ''
                        )
                      : candidatesForDepartment(modal.departmentId)
                  ).map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              )}
              {(modal.kind === 'assignDepartmentHead' || modal.kind === 'assignTeamHead') && (
                <p className="text-xs text-gray-500 dark:text-zinc-400 -mt-2">
                  {modal.kind === 'assignDepartmentHead'
                    ? '이 부문 소속 인원과 미지정 인원만 선택할 수 있어요.'
                    : '이 부서 소속 인원과 미지정 인원만 선택할 수 있어요.'}
                </p>
              )}

              {modal.kind === 'addApprover' && (
                <>
                  <select
                    value={modalUserId}
                    onChange={(e) => setModalUserId(e.target.value)}
                    className="w-full border rounded-lg px-3.5 py-2.5 text-sm dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200"
                  >
                    <option value="">위임할 사람 선택</option>
                    {allProfiles.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                  <div>
                    <p className="text-xs text-gray-500 dark:text-zinc-400 mb-2.5">
                      어떤 유형을 위임할까요?
                    </p>
                    <div className="flex gap-4">
                      {[
                        { key: 'can_vacation', label: '휴가' },
                        { key: 'can_remote', label: '원격근무' },
                        { key: 'can_holiday', label: '휴일근무' },
                      ].map(({ key, label }) => (
                        <label
                          key={key}
                          className="flex items-center gap-1.5 text-sm dark:text-zinc-200"
                        >
                          <input
                            type="checkbox"
                            checked={(modalChecks as any)[key]}
                            onChange={(e) =>
                              setModalChecks((s) => ({ ...s, [key]: e.target.checked }))
                            }
                          />
                          {label}
                        </label>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {message && <p className="text-xs text-red-500">{message}</p>}
            </div>

            <div className="flex gap-3 mt-7">
              <Button variant="secondary" className="flex-1" onClick={closeModal}>
                취소
              </Button>
              <Button className="flex-1" onClick={submitModal}>
                확인
              </Button>
            </div>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={!!pendingConfirm}
        tone={pendingConfirm?.tone ?? 'normal'}
        title={pendingConfirm?.title ?? ''}
        description={pendingConfirm?.description}
        confirmLabel={pendingConfirm?.confirmLabel}
        onCancel={() => setPendingConfirm(null)}
        onConfirm={() => pendingConfirm?.onConfirm()}
      />
    </div>
  )
}

// 사이드바 조직 트리(부문 → 부서 → 팀)의 한 행. 세 단계가 모두 이 컴포넌트를 써서
// "화살표 자리 · 이름 · 인원수" 구조와 들여쓰기 간격이 단계와 무관하게 똑같다.
// - 화살표 칸은 하위 항목이 없어도 같은 폭을 차지한다 (형제끼리 이름 위치가 어긋나지 않도록).
// - 단계별로 달라지는 건 글자 크기/굵기/세로 여백뿐이다.
type TreeLevel = 0 | 1 | 2
const TREE_LEVEL_STYLE: Record<
  TreeLevel,
  { row: string; text: string; idle: string; selected: string }
> = {
  0: {
    row: 'py-2.5',
    text: 'text-sm',
    idle: 'text-gray-700 dark:text-zinc-200 font-medium',
    selected: 'text-blue-600 dark:text-blue-400 font-semibold',
  },
  1: {
    row: 'py-1.5',
    text: 'text-[13px]',
    idle: 'text-gray-500 dark:text-zinc-400',
    selected: 'text-blue-600 dark:text-blue-400 font-medium',
  },
  2: {
    row: 'py-1',
    text: 'text-[12px]',
    idle: 'text-gray-500 dark:text-zinc-400',
    selected: 'text-blue-600 dark:text-blue-400 font-medium',
  },
}
// 하위 목록 컨테이너: 안내선이 부모 행의 화살표 칸 중앙 아래에 오고, 자식 행의 화살표가
// 부모 이름 시작 위치와 맞물리도록 모든 단계에서 같은 값을 쓴다.
const TREE_CHILDREN_CLASS =
  'ml-[15px] pl-1 mt-0.5 mb-1 border-l-2 border-gray-100 dark:border-zinc-700 space-y-0.5 min-w-0 overflow-hidden'

function TreeRow({
  level,
  label,
  count,
  selected,
  hasChildren,
  open,
  onClick,
}: {
  level: TreeLevel
  label: string
  count?: number
  selected: boolean
  hasChildren: boolean
  open: boolean
  onClick: () => void
}) {
  const style = TREE_LEVEL_STYLE[level]
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-1 px-2 rounded-lg text-left min-w-0 ${style.row} ${
        selected ? 'bg-blue-50 dark:bg-blue-500/10' : 'hover:bg-gray-50 dark:hover:bg-zinc-700/50'
      }`}
    >
      <span
        className="w-4 shrink-0 text-center text-[11px] text-gray-500 dark:text-zinc-400"
        aria-hidden
      >
        {hasChildren ? (open ? '▾' : '▸') : ''}
      </span>
      <span
        className={`flex-1 min-w-0 truncate ${style.text} ${selected ? style.selected : style.idle}`}
      >
        {label}
      </span>
      {count !== undefined && (
        <span className="text-[11px] text-gray-300 dark:text-zinc-600 shrink-0">{count}</span>
      )}
    </button>
  )
}

function TabBar({
  tabs,
  active,
  onChange,
}: {
  tabs: { key: string; label: string }[]
  active: string
  onChange: (key: string) => void
}) {
  return (
    <div className="flex gap-4 border-b border-gray-200 dark:border-zinc-700 mb-4">
      {tabs.map((t) => (
        <button
          key={t.key}
          onClick={() => onChange(t.key)}
          className={`pb-2 text-sm font-medium border-b-2 -mb-px transition ${
            active === t.key
              ? 'border-blue-500 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-gray-500 dark:text-zinc-400 hover:text-gray-600 dark:hover:text-zinc-300'
          }`}
        >
          {t.label}
        </button>
      ))}
    </div>
  )
}

/**
 * 구성원 행 오른쪽 끝의 ⋮ 버튼. 누르면 이동/내보내기 선택지가 펼쳐지고,
 * "이동"을 고르면 movingKey가 이 행으로 바뀌면서 MoveForm으로 전환된다.
 * canMove/canRemove가 모두 false면 아무것도 렌더링하지 않는다(권한 없는 행은 조용히 생략).
 */
function MemberActionMenu({
  rowKey,
  openKey,
  setOpenKey,
  movingKey,
  moveForm,
  onMoveClick,
  onRemoveClick,
  canMove,
  canRemove,
}: {
  rowKey: string
  openKey: string | null
  setOpenKey: (v: string | null) => void
  movingKey: string | null
  moveForm?: ReactNode
  onMoveClick?: () => void
  onRemoveClick?: () => void
  canMove: boolean
  canRemove: boolean
}) {
  if (movingKey === rowKey) {
    return <div className="w-full flex justify-end mt-1">{moveForm}</div>
  }
  if (!canMove && !canRemove) return null
  const isOpen = openKey === rowKey
  return (
    <div className="relative shrink-0">
      <button
        onClick={() => setOpenKey(isOpen ? null : rowKey)}
        className="w-6 h-6 flex items-center justify-center rounded text-gray-500 dark:text-zinc-400 hover:bg-gray-100 dark:hover:bg-zinc-800 hover:text-gray-600 dark:hover:text-zinc-300 leading-none text-base"
        aria-label="더보기"
      >
        ⋮
      </button>
      {isOpen && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpenKey(null)} />
          <div className="absolute right-0 top-full mt-1 z-20 min-w-[92px] bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 rounded-lg shadow-lg py-1 flex flex-col">
            {canMove && (
              <button
                onClick={() => {
                  setOpenKey(null)
                  onMoveClick?.()
                }}
                className="px-3 py-1.5 text-xs text-left text-blue-500 hover:bg-gray-50 dark:hover:bg-zinc-700"
              >
                이동
              </button>
            )}
            {canRemove && (
              <button
                onClick={() => {
                  setOpenKey(null)
                  onRemoveClick?.()
                }}
                className="px-3 py-1.5 text-xs text-left text-red-500 hover:bg-gray-50 dark:hover:bg-zinc-700"
              >
                내보내기
              </button>
            )}
          </div>
        </>
      )}
    </div>
  )
}

function MoveForm({
  departmentsForActor,
  moveTargetDept,
  setMoveTargetDept,
  moveTargetTeam,
  setMoveTargetTeam,
  teamsInDept,
  onConfirm,
  onCancel,
}: {
  departmentsForActor: DepartmentRow[]
  moveTargetDept: string
  setMoveTargetDept: (v: string) => void
  moveTargetTeam: string
  setMoveTargetTeam: (v: string) => void
  teamsInDept: (departmentId: string) => { id: string; name: string }[]
  onConfirm: () => void
  onCancel: () => void
}) {
  const availableTeams = moveTargetDept ? teamsInDept(moveTargetDept) : []
  return (
    <span className="inline-flex flex-wrap items-center gap-1 max-w-full">
      <select
        value={moveTargetDept}
        onChange={(e) => {
          setMoveTargetDept(e.target.value)
          setMoveTargetTeam('')
        }}
        className="border rounded-lg px-1.5 py-0.5 text-[11px] dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200 max-w-[40vw] sm:max-w-[160px]"
      >
        {departmentsForActor.map((d) => (
          <option key={d.id} value={d.id}>
            {d.name}
          </option>
        ))}
      </select>
      <select
        value={moveTargetTeam}
        onChange={(e) => setMoveTargetTeam(e.target.value)}
        className="border rounded-lg px-1.5 py-0.5 text-[11px] dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200 max-w-[40vw] sm:max-w-[160px]"
      >
        <option value="">부서 직속</option>
        {availableTeams.map((t) => (
          <option key={t.id} value={t.id}>
            {t.name}
          </option>
        ))}
      </select>
      <button
        onClick={onConfirm}
        className="text-[11px] text-green-500 font-medium shrink-0 px-1 py-0.5"
      >
        확인
      </button>
      <button onClick={onCancel} className="text-[11px] text-gray-400 shrink-0 px-1 py-0.5">
        취소
      </button>
    </span>
  )
}

/**
 * 순서변경 모드에서만 쓰는 드래그 앤 드롭 리스트.
 * disabled=false일 때만 실제로 draggable이 걸리고, 그 외에는 평범한 목록으로 렌더링된다.
 * 다른 그룹과 섞이지 않도록 항상 "하나의 그룹" 단위로만 사용한다 (예: 특정 부서 직속 인원, 특정 팀 인원).
 */
function DragList<T>({
  items,
  getKey,
  renderItem,
  onReorder,
  disabled,
}: {
  items: T[]
  getKey: (item: T) => string
  renderItem: (item: T) => ReactNode
  onReorder: (newItems: T[]) => void
  disabled?: boolean
}) {
  const [dragKey, setDragKey] = useState<string | null>(null)
  const [overKey, setOverKey] = useState<string | null>(null)

  if (disabled) {
    return (
      <>
        {items.map((item) => (
          <div key={getKey(item)}>{renderItem(item)}</div>
        ))}
      </>
    )
  }

  const handleDrop = (targetKey: string) => {
    setOverKey(null)
    if (!dragKey || dragKey === targetKey) return
    const fromIdx = items.findIndex((i) => getKey(i) === dragKey)
    const toIdx = items.findIndex((i) => getKey(i) === targetKey)
    if (fromIdx === -1 || toIdx === -1) return
    const next = [...items]
    const [moved] = next.splice(fromIdx, 1)
    next.splice(toIdx, 0, moved)
    onReorder(next)
  }

  return (
    <>
      {items.map((item) => {
        const key = getKey(item)
        return (
          <div
            key={key}
            draggable
            onDragStart={() => setDragKey(key)}
            onDragOver={(e) => {
              e.preventDefault()
              if (overKey !== key) setOverKey(key)
            }}
            onDragLeave={() => setOverKey((k) => (k === key ? null : k))}
            onDrop={(e) => {
              e.preventDefault()
              handleDrop(key)
            }}
            onDragEnd={() => {
              setDragKey(null)
              setOverKey(null)
            }}
            className={`cursor-grab active:cursor-grabbing rounded-lg transition ${
              dragKey === key ? 'opacity-40' : ''
            } ${overKey === key && dragKey !== key ? 'ring-2 ring-blue-300 dark:ring-blue-600' : ''}`}
          >
            <div className="flex items-center gap-1.5">
              <span className="shrink-0 text-gray-300 dark:text-zinc-600 select-none" aria-hidden>
                ⠿
              </span>
              <div className="flex-1 min-w-0">{renderItem(item)}</div>
            </div>
          </div>
        )
      })}
    </>
  )
}
