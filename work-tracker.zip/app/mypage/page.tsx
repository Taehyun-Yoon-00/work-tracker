'use client'

import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useRouter } from 'next/navigation'
import dayjs from 'dayjs'
import ConfirmDialog from '../components/ui/ConfirmDialog'
import SectionHeader from '../components/ui/SectionHeader'

export default function MyPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [name, setName] = useState('')
  const [position, setPosition] = useState('')
  const [totalVacation, setTotalVacation] = useState<number>(0)
  const [usedVacation, setUsedVacation] = useState<number>(0)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [isMaster, setIsMaster] = useState(false)
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [passwordMessage, setPasswordMessage] = useState('')
  const [passwordLoading, setPasswordLoading] = useState(false)
  const [deleteConfirm, setDeleteConfirm] = useState('')
  const [deleteLoading, setDeleteLoading] = useState(false)
  const [deleteMessage, setDeleteMessage] = useState('')
  const [confirmingDelete, setConfirmingDelete] = useState(false)
  const [showDeleteSection, setShowDeleteSection] = useState(false)

  useEffect(() => {
    const getUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        router.push('/login')
        return
      }
      setUser(user)
      fetchProfile(user.id)
      fetchUsedVacation(user.id)
    }
    getUser()
  }, [])

  const fetchProfile = async (userId: string) => {
    const { data } = await supabase
      .from('profiles')
      .select('name, position, total_vacation, is_master')
      .eq('id', userId)
      .single()
    if (data) {
      setName(data.name || '')
      setPosition(data.position || '')
      setTotalVacation(data.total_vacation || 0)
      if (data.is_master) setIsMaster(true)
    }
  }

  const fetchUsedVacation = async (userId: string) => {
    const now = dayjs()
    const fiscalYearStart = now.month() >= 3 ? now.year() : now.year() - 1
    const startDate = `${fiscalYearStart}-04-01`
    const endDate = `${fiscalYearStart + 1}-03-31`

    const { data } = await supabase
      .from('vacations')
      .select('type')
      .eq('user_id', userId)
      .gte('date', startDate)
      .lte('date', endDate)

    if (data) {
      const used = data.reduce((acc, v) => {
        if (v.type === 'annual') return acc + 1
        if (v.type === 'morning' || v.type === 'afternoon') return acc + 0.5
        if (v.type === 'special') return acc + 0
        return acc
      }, 0)
      setUsedVacation(used)
    }
  }

  const handleSave = async () => {
    setLoading(true)
    setMessage('')
    const { error } = await supabase
      .from('profiles')
      .update({ name, position, total_vacation: totalVacation })
      .eq('id', user.id)

    if (error) setMessage('저장 실패: ' + error.message)
    else setMessage('저장 완료!')
    setLoading(false)
  }

  const handlePasswordChange = async () => {
    if (!newPassword || newPassword.length < 6) {
      setPasswordMessage('비밀번호는 6자리 이상이어야 해요.')
      return
    }
    setPasswordLoading(true)
    const { error } = await supabase.auth.updateUser({ password: newPassword })
    if (error) setPasswordMessage('변경 실패: ' + error.message)
    else {
      setPasswordMessage('비밀번호가 변경됐어요!')
      setNewPassword('')
    }
    setPasswordLoading(false)
  }

  const handleDeleteAccount = async () => {
    if (!user) return
    if (deleteConfirm !== user.email) {
      setDeleteMessage('이메일 주소가 일치하지 않아요.')
      return
    }

    setDeleteMessage('')
    setDeleteLoading(true)

    const res = await fetch('/api/admin/delete-user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user.id }),
    })

    if (!res.ok) {
      const data = await res.json()
      setDeleteMessage('탈퇴 처리 중 오류가 발생했어요: ' + (data.error || '알 수 없는 오류'))
      setDeleteLoading(false)
      return
    }

    await supabase.auth.signOut()
    router.push('/login')
    setDeleteLoading(false)
  }

  const remaining = totalVacation - usedVacation

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-zinc-900 p-2 sm:p-4 pb-28">
      <div className="max-w-2xl mx-auto">
        {/* 헤더 */}
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-xl font-semibold dark:text-white">마이페이지</h1>
          {isMaster && (
            <button
              onClick={() => router.push('/admin')}
              className="text-sm text-red-500 hover:underline"
            >
              회원 관리
            </button>
          )}
        </div>

        {/* 계정 — 기본 정보와 비밀번호를 하나의 Settings 패널 안에서 구분선으로 나눈다.
           (개별 항목마다 흰 카드를 새로 만들지 않고, 같은 성격의 설정을 한 패널에 묶는다) */}
        <div className="bg-white dark:bg-zinc-800 rounded-lg border border-gray-200 dark:border-zinc-700 p-4 mb-4 divide-y divide-gray-100 dark:divide-zinc-700">
          <div className="pb-4">
            <SectionHeader className="mb-3">계정</SectionHeader>

            <div className="mb-4">
              <label className="text-sm text-gray-500 dark:text-zinc-400">이메일</label>
              <p className="text-sm font-medium mt-1 dark:text-zinc-200">{user?.email}</p>
            </div>

            <div className="mb-4">
              <label className="text-sm text-gray-500 dark:text-zinc-400">이름</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="이름을 입력해주세요"
                className="w-full border rounded-lg px-3 py-2 mt-1 dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200"
              />
            </div>

            <div className="mb-4">
              <label className="text-sm text-gray-500 dark:text-zinc-400">직급</label>
              <input
                type="text"
                value={position}
                onChange={(e) => setPosition(e.target.value)}
                placeholder="직급을 입력해주세요"
                className="w-full border rounded-lg px-3 py-2 mt-1 dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200"
              />
            </div>

            <div className="mb-4">
              <label className="text-sm text-gray-500 dark:text-zinc-400">총 휴가 일수</label>
              <div className="flex items-center gap-2 mt-1">
                <input
                  type="number"
                  value={totalVacation}
                  onChange={(e) => setTotalVacation(parseFloat(e.target.value))}
                  step="0.5"
                  min="0"
                  className="w-full border rounded-lg px-3 py-2 dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200"
                />
                <span className="text-sm text-gray-500 dark:text-zinc-400 shrink-0">일</span>
              </div>
              <p className="text-xs text-gray-400 dark:text-zinc-500 mt-1">
                반차는 0.5일로 계산돼요
              </p>
            </div>

            {message && <p className="text-sm text-center text-blue-500 mb-3">{message}</p>}

            <button
              onClick={handleSave}
              disabled={loading}
              className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 disabled:opacity-50"
            >
              {loading ? '저장 중...' : '저장'}
            </button>
          </div>

          <div className="pt-4">
            <SectionHeader className="mb-3">비밀번호</SectionHeader>
            <div className="mb-3">
              <label className="text-sm text-gray-500 dark:text-zinc-400">새 비밀번호</label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="6자리 이상"
                className="w-full border rounded-lg px-3 py-2 mt-1 dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200"
              />
            </div>
            {passwordMessage && (
              <p className="text-sm text-center text-blue-500 mb-3">{passwordMessage}</p>
            )}
            <button
              onClick={handlePasswordChange}
              disabled={passwordLoading}
              className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 disabled:opacity-50"
            >
              {passwordLoading ? '변경 중...' : '비밀번호 변경'}
            </button>
          </div>
        </div>

        {/* 휴가 현황 — 설정이 아니라 데이터 요약이므로 별도 패널로 둔다 */}
        <div className="bg-white dark:bg-zinc-800 rounded-lg border border-gray-200 dark:border-zinc-700 p-4 mb-4">
          <SectionHeader className="mb-3">올해 휴가 현황</SectionHeader>
          <div className="grid grid-cols-3 divide-x divide-gray-100 dark:divide-zinc-700 mb-4">
            <div className="text-center">
              <p className="text-xs text-gray-500 dark:text-zinc-400 mb-1">총 휴가</p>
              <p className="text-lg font-semibold dark:text-white">{totalVacation}일</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-500 dark:text-zinc-400 mb-1">사용</p>
              <p className="text-lg font-semibold text-orange-500">{usedVacation}일</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-500 dark:text-zinc-400 mb-1">잔여</p>
              <p className="text-lg font-semibold text-blue-500">{remaining}일</p>
            </div>
          </div>
          <div className="w-full bg-gray-100 dark:bg-zinc-700 rounded-full h-2">
            <div
              className="bg-blue-500 h-2 rounded-full transition-all"
              style={{
                width:
                  totalVacation > 0 ? `${Math.max(0, (remaining / totalVacation) * 100)}%` : '0%',
              }}
            />
          </div>
          <div className="flex justify-between text-xs text-gray-400 dark:text-zinc-500 mt-1">
            <span>0일</span>
            <span>{totalVacation}일</span>
          </div>
        </div>

        {/* 계정 관리 (위험 구역) — 파괴적 동작이므로 border 색으로만 구분하고, 배경 전체를
           붉게 칠하지는 않는다 */}
        <div className="bg-white dark:bg-zinc-800 rounded-lg border border-red-200 dark:border-red-900/60 p-4">
          <SectionHeader
            action={
              <button
                onClick={() => setShowDeleteSection(!showDeleteSection)}
                className="text-sm text-red-500 hover:underline"
              >
                {showDeleteSection ? '닫기' : '회원 탈퇴'}
              </button>
            }
          >
            계정 관리
          </SectionHeader>

          {showDeleteSection && (
            <div className="mt-4 pt-4 border-t border-red-100 dark:border-red-900/40">
              <p className="text-sm text-gray-500 dark:text-zinc-400 mb-3">
                탈퇴하면 모든 근무 기록, 휴가, 팀 정보가 삭제되며 복구할 수 없어요.
                <br />
                확인을 위해 이메일 주소를 입력해주세요.
              </p>
              <input
                type="text"
                value={deleteConfirm}
                onChange={(e) => setDeleteConfirm(e.target.value)}
                placeholder={user?.email}
                className="w-full border border-red-200 rounded-lg px-3 py-2 mb-3 dark:bg-zinc-700 dark:border-red-900 dark:text-zinc-200"
              />
              {deleteMessage && <p className="text-sm text-red-500 mb-3">{deleteMessage}</p>}
              <button
                onClick={() => setConfirmingDelete(true)}
                disabled={deleteLoading || deleteConfirm !== user?.email}
                className="w-full bg-red-500 text-white py-2 rounded-lg hover:bg-red-600 disabled:opacity-40"
              >
                {deleteLoading ? '처리 중...' : '회원 탈퇴'}
              </button>
            </div>
          )}
        </div>

        <ConfirmDialog
          open={confirmingDelete}
          tone="danger"
          busy={deleteLoading}
          title="정말로 탈퇴하시겠어요?"
          description="모든 근무 기록, 휴가, 팀 정보가 삭제되며 복구할 수 없어요."
          confirmLabel="탈퇴"
          onCancel={() => setConfirmingDelete(false)}
          onConfirm={() => {
            setConfirmingDelete(false)
            handleDeleteAccount()
          }}
        />
      </div>
    </div>
  )
}
