'use client'

import { useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import dayjs from 'dayjs'
import { supabase } from '../lib/supabase'
import { getSettlementPeriod } from '../lib/dates'
import Button from '../components/ui/Button'

interface MatterRow {
  category: string
  hours: number
  matter_place: string | null
  matter_division: string | null
  matter_content: string | null
  matter_cost_code: string | null
}

interface MatterSummary {
  key: string
  name: string
  hours: number
}

function matterDisplayName(row: MatterRow): string {
  if (row.category !== '청구안건') return row.category
  const label = row.matter_content?.trim() || row.matter_place?.trim() || '청구 안건'
  return row.matter_cost_code?.trim() ? `${label} (${row.matter_cost_code.trim()})` : label
}

interface TemplateInfo {
  filename: string
  uploadedAt: string
  uploadedBy: string
}

// 출력 양식 종류. report_templates.kind / 출력 API와 1:1로 대응한다.
type ExportKind = 'support_list' | 'attendance'

const EXPORT_CONFIG: Record<ExportKind, { label: string; endpoint: string; defaultName: string }> = {
  support_list: {
    label: '서포트리스트',
    endpoint: '/api/report/export-excel',
    defaultName: '서포트리스트',
  },
  attendance: {
    label: '근무관리표',
    endpoint: '/api/report/export-attendance',
    defaultName: '근무관리표',
  },
}
const EXPORT_KINDS: ExportKind[] = ['support_list', 'attendance']

export default function ReportPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const today = useMemo(() => dayjs(), [])
  const [targetYear, setTargetYear] = useState(today.year())
  const [targetMonth, setTargetMonth] = useState(today.month() + 1) // 1-12
  const [summary, setSummary] = useState<MatterSummary[]>([])
  const [loading, setLoading] = useState(false)

  // 엑셀 출력(서포트리스트/근무관리표) 관련 상태 — 한 번에 하나만 출력한다.
  const [exporting, setExporting] = useState<ExportKind | null>(null)
  const [exportMessage, setExportMessage] = useState('')

  // 출력 양식 업로드는 총괄 관리자/마스터만 볼 수 있다. (일반 사용자는 본인 데이터가 채워진 결과물만 받는다)
  const [canManageTemplate, setCanManageTemplate] = useState(false)
  const [templateInfo, setTemplateInfo] = useState<Record<ExportKind, TemplateInfo | null>>({
    support_list: null,
    attendance: null,
  })
  const [uploadingTemplate, setUploadingTemplate] = useState<ExportKind | null>(null)
  const [templateMessage, setTemplateMessage] = useState<{ kind: ExportKind; text: string } | null>(
    null
  )

  const fetchTemplateInfo = async (kind: ExportKind) => {
    const res = await fetch(`/api/admin/report-template?kind=${kind}`)
    const data = await res.json()
    if (res.ok) setTemplateInfo((prev) => ({ ...prev, [kind]: data.template }))
  }

  useEffect(() => {
    const getUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        router.push('/login')
        return
      }
      setUser(user)

      // 총괄 관리자/마스터 여부 확인 — 출력 양식 업로드 카드 노출 여부에만 쓴다.
      // (실제 권한 검사는 /api/admin/report-template 라우트가 서버에서 다시 한다.)
      const [{ data: profileData }, { data: generalAdminRow }] = await Promise.all([
        supabase.from('profiles').select('is_master').eq('id', user.id).single(),
        supabase.from('general_admins').select('user_id').eq('user_id', user.id).maybeSingle(),
      ])
      const isAllowed = !!profileData?.is_master || !!generalAdminRow
      setCanManageTemplate(isAllowed)
      if (isAllowed) EXPORT_KINDS.forEach(fetchTemplateInfo)
    }
    getUser()
  }, [])

  const handleTemplateUpload = async (kind: ExportKind, file: File) => {
    setUploadingTemplate(kind)
    setTemplateMessage(null)
    const formData = new FormData()
    formData.append('file', file)
    formData.append('kind', kind)
    const res = await fetch('/api/admin/report-template', { method: 'POST', body: formData })
    const data = await res.json()
    if (!res.ok || data.error) {
      setTemplateMessage({
        kind,
        text: data.error ? data.error : '업로드 실패: 알 수 없는 오류',
      })
    } else {
      setTemplateMessage({ kind, text: `${EXPORT_CONFIG[kind].label} 양식이 업로드됐어요!` })
      fetchTemplateInfo(kind)
    }
    setUploadingTemplate(null)
  }

  const handleExport = async (kind: ExportKind) => {
    const config = EXPORT_CONFIG[kind]
    setExporting(kind)
    setExportMessage('')
    const res = await fetch(config.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ year: targetYear, month: targetMonth }),
    })
    if (!res.ok) {
      const data = await res.json().catch(() => ({}))
      setExportMessage(data.error || '출력에 실패했어요.')
      setExporting(null)
      return
    }
    const blob = await res.blob()
    const disposition = res.headers.get('Content-Disposition') || ''
    const match = disposition.match(/filename\*=UTF-8''([^;]+)/)
    const filename = match
      ? decodeURIComponent(match[1])
      : `${config.defaultName}_${targetYear}_${targetMonth}.xlsx`

    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
    setExporting(null)
  }

  // 선택한 "당월"을 기준으로 전월 16일 ~ 당월 15일 범위를 계산.
  // 이 규칙은 팀 상세 페이지와도 같아서 lib/dates.ts의 getSettlementPeriod를 함께 쓴다.
  const { periodStart, periodEnd } = useMemo(() => {
    const targetMonthStart = dayjs(`${targetYear}-${String(targetMonth).padStart(2, '0')}-01`)
    const { start, end } = getSettlementPeriod(targetMonthStart)
    return { periodStart: start, periodEnd: end }
  }, [targetYear, targetMonth])

  useEffect(() => {
    if (user) fetchSummary()
  }, [user, periodStart, periodEnd])

  const fetchSummary = async () => {
    setLoading(true)
    const { data, error } = await supabase
      .from('work_log_matters')
      .select(
        'category, hours, matter_place, matter_division, matter_content, matter_cost_code, work_logs!inner(date, user_id)'
      )
      .eq('work_logs.user_id', user.id)
      .gte('work_logs.date', periodStart)
      .lte('work_logs.date', periodEnd)

    if (error) {
      console.error('리포트 조회 실패:', error.message)
      setSummary([])
      setLoading(false)
      return
    }

    const grouped = new Map<string, number>()
    ;(data || []).forEach((row: any) => {
      const name = matterDisplayName(row)
      grouped.set(name, (grouped.get(name) || 0) + Number(row.hours))
    })

    const rows: MatterSummary[] = Array.from(grouped.entries())
      .map(([name, hours]) => ({ key: name, name, hours: Math.round(hours * 100) / 100 }))
      .sort((a, b) => b.hours - a.hours)

    setSummary(rows)
    setLoading(false)
  }

  const totalHours = Math.round(summary.reduce((acc, r) => acc + r.hours, 0) * 100) / 100

  const moveMonth = (diff: number) => {
    const next = dayjs(`${targetYear}-${String(targetMonth).padStart(2, '0')}-01`).add(
      diff,
      'month'
    )
    setTargetYear(next.year())
    setTargetMonth(next.month() + 1)
  }

  // 연도 선택지: 5년 전 ~ 내년. 12월에서 다음 달(내년 1월)로 넘길 수 있고, 그때 select에 해당 연도가
  // 없으면 상태는 바뀌었는데 화면에는 이전 연도가 남아 보이므로, 현재 선택된 연도는 항상 포함한다.
  const yearOptions = useMemo(() => {
    const nowYear = today.year()
    const maxYear = Math.max(nowYear + 1, targetYear)
    const minYear = Math.min(nowYear - 5, targetYear)
    const years: number[] = []
    for (let y = maxYear; y >= minYear; y--) years.push(y)
    return years
  }, [today, targetYear])

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-zinc-900 p-2 sm:p-4 pb-28">
      <div className="max-w-2xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-xl font-semibold dark:text-white">리포트</h1>
        </div>

        {/* 년/월 선택 */}
        <div className="bg-white dark:bg-zinc-800 rounded-lg border border-gray-200 dark:border-zinc-700 p-4 mb-4">
          <div className="flex items-center justify-center gap-2">
            <button
              onClick={() => moveMonth(-1)}
              aria-label="이전 달"
              className="w-8 h-8 flex items-center justify-center rounded-full text-gray-400 dark:text-zinc-400 hover:bg-gray-100 dark:hover:bg-zinc-700"
            >
              ‹
            </button>

            <select
              value={targetYear}
              onChange={(e) => setTargetYear(Number(e.target.value))}
              className="border rounded-lg px-2 py-1.5 text-sm dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200"
            >
              {yearOptions.map((y) => (
                <option key={y} value={y}>
                  {y}년
                </option>
              ))}
            </select>

            <select
              value={targetMonth}
              onChange={(e) => setTargetMonth(Number(e.target.value))}
              className="border rounded-lg px-2 py-1.5 text-sm dark:bg-zinc-700 dark:border-zinc-600 dark:text-zinc-200"
            >
              {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
                <option key={m} value={m}>
                  {m}월
                </option>
              ))}
            </select>

            <button
              onClick={() => moveMonth(1)}
              aria-label="다음 달"
              className="w-8 h-8 flex items-center justify-center rounded-full text-gray-400 dark:text-zinc-400 hover:bg-gray-100 dark:hover:bg-zinc-700"
            >
              ›
            </button>
          </div>
          <p className="text-center text-xs text-gray-500 dark:text-zinc-400 mt-2">
            {dayjs(periodStart).format('YYYY.MM.DD')} ~ {dayjs(periodEnd).format('YYYY.MM.DD')}
          </p>

          {/* 엑셀 출력 — 총괄 관리자가 올려둔 양식에 본인의 이 기간 기록을 채워 넣는다 */}
          <div className="grid grid-cols-2 gap-2 mt-3">
            {EXPORT_KINDS.map((kind) => (
              <Button key={kind} onClick={() => handleExport(kind)} disabled={exporting !== null}>
                {exporting === kind ? '만드는 중...' : `${EXPORT_CONFIG[kind].label} 출력`}
              </Button>
            ))}
          </div>
          {exportMessage && (
            <p className="text-xs text-red-500 text-center mt-2">{exportMessage}</p>
          )}
        </div>

        {/* 출력 양식 관리 (총괄 관리자/마스터 전용) */}
        {canManageTemplate && (
          <div className="bg-white dark:bg-zinc-800 rounded-lg border border-gray-200 dark:border-zinc-700 p-4 mb-4">
            <h2 className="font-semibold mb-1 dark:text-white">출력 양식 관리</h2>
            <p className="text-xs text-gray-500 dark:text-zinc-400 mb-3">
              출력에 쓰는 엑셀 양식(.xlsx)이에요. 새로 업로드하면 그 다음 출력부터 바로 최신 양식이
              적용돼요.
            </p>
            <div className="divide-y dark:divide-zinc-700">
              {EXPORT_KINDS.map((kind) => {
                const info = templateInfo[kind]
                return (
                  <div key={kind} className="py-3 first:pt-0 last:pb-0">
                    <p className="text-sm font-medium dark:text-zinc-200 mb-1">
                      {EXPORT_CONFIG[kind].label} 양식
                    </p>
                    {info ? (
                      <p className="text-xs text-gray-500 dark:text-zinc-400 mb-2">
                        현재 양식: <span className="font-medium">{info.filename}</span>
                        <br />
                        {dayjs(info.uploadedAt).format('YYYY.MM.DD HH:mm')} · {info.uploadedBy} 업로드
                      </p>
                    ) : (
                      <p className="text-xs text-gray-500 dark:text-zinc-400 mb-2">
                        아직 업로드된 양식이 없어요.
                      </p>
                    )}
                    <input
                      type="file"
                      accept=".xlsx"
                      disabled={uploadingTemplate !== null}
                      onChange={(e) => {
                        const file = e.target.files?.[0]
                        if (file) handleTemplateUpload(kind, file)
                        e.target.value = ''
                      }}
                      className="text-sm text-gray-600 dark:text-zinc-300"
                    />
                    {uploadingTemplate === kind && (
                      <p className="text-xs text-gray-500 dark:text-zinc-400 mt-2">업로드 중...</p>
                    )}
                    {templateMessage?.kind === kind && (
                      <p className="text-xs text-blue-500 mt-2">{templateMessage.text}</p>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* 안건별 합계시간 */}
        <div className="bg-white dark:bg-zinc-800 rounded-lg border border-gray-200 dark:border-zinc-700 p-4">
          {loading ? (
            <p className="text-sm text-gray-500 dark:text-zinc-400 text-center py-6">
              불러오는 중...
            </p>
          ) : summary.length === 0 ? (
            <p className="text-sm text-gray-500 dark:text-zinc-400 text-center py-6">
              해당 기간에 기록된 근무가 없어요.
            </p>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b dark:border-zinc-700 text-left text-gray-500 dark:text-zinc-400">
                  <th className="py-2 font-medium">안건명</th>
                  <th className="py-2 font-medium text-right">합계 시간</th>
                </tr>
              </thead>
              <tbody>
                {summary.map((row) => (
                  <tr key={row.key} className="border-b last:border-0 dark:border-zinc-700">
                    <td className="py-2.5 pr-2 dark:text-zinc-200 break-words">{row.name}</td>
                    <td className="py-2.5 text-right font-medium dark:text-zinc-200 whitespace-nowrap">
                      {row.hours.toFixed(2)}시간
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td className="pt-3 font-semibold dark:text-white">합계</td>
                  <td className="pt-3 text-right font-semibold dark:text-white whitespace-nowrap">
                    {totalHours.toFixed(2)}시간
                  </td>
                </tr>
              </tfoot>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}
